# Mobile Robot Localization

A complete, runnable college project for **Computational Foundations for AI
(25SC1306E)** that exercises the **whole syllabus (CO1–CO6)**.

A simulated mobile robot drives across a 2D grid world while it figures out
where it is from noisy sensors. You can:

- plan its route with six algorithms — **BFS, DFS, UCS, Greedy, A\*** and a
  **CSP Min-Conflicts** planner (CO2/CO3),
- localize it with two different filters — an exact **histogram / Bayes
  (Markov) filter** and a sampling **particle filter** (CO5),
- let it **actively choose moves that reduce its own uncertainty** (CO4),
- solve a **backtracking CSP** that assigns non-interfering sensor channels to
  map zones (CO3), and
- read a **step-by-step reasoning trace** of everything it did (CO6).

Everything runs in the browser from a single command.

---

## Table of contents

1. [What is localization?](#1-what-is-localization)
2. [How the project maps to CO1–CO6](#2-how-the-project-maps-to-co1co6)
3. [Tech stack](#3-tech-stack)
4. [Folder structure](#4-folder-structure)
5. [Installation (read this — avoids the Python 3.14 trap)](#5-installation)
6. [Running the app](#6-running-the-app)
7. [Using the web interface](#7-using-the-web-interface)
8. [API documentation](#8-api-documentation)
9. [Database schema](#9-database-schema)
10. [Testing](#10-testing)
11. [Code walkthrough — every file explained](#11-code-walkthrough--every-file-explained)
12. [Suggested extra features](#12-suggested-extra-features)

---

## 1. What is localization?

A robot rarely knows its exact position. Instead it keeps a **belief**: a
probability for every cell answering *"how likely is it that I'm here?"*. As the
robot moves and senses, it repeats two steps:

- **Predict (motion update):** "I moved RIGHT, so shift my belief right."
- **Update (sensor update):** "My sensors read these distances — which cells
  match?" Matching cells get boosted; the rest shrink; then re-normalise.

After a few steps the belief concentrates on the true cell. We measure quality
with the **localization error** = grid distance between the true cell and the
estimated (most-likely) cell.

This project implements that idea **two ways**, which is itself a lesson:

- the **histogram filter** keeps an exact probability for every cell (precise,
  but stores a full grid), and
- the **particle filter** keeps a cloud of sampled guesses (approximate, but
  only tracks cells that matter).

Switching between them in the UI lets you *see* the accuracy/cost trade-off.

---

## 2. How the project maps to CO1–CO6

| Outcome | What the syllabus asks | Where it lives |
|---|---|---|
| **CO1** | Represent tasks as states/actions/goals in Python with traceable reasoning | `core/grid.py`, `core/robot.py`, the reasoning trace |
| **CO2** | Search: BFS, DFS, UCS, Greedy, A\*; heuristics; time/space trade-offs | `core/planners.py`, the "Compare planners" button |
| **CO3** | CSP via **backtracking + propagation + MRV/degree/LCV**; resource tasks | `core/csp_backtracking.py` (channel assignment) and `core/csp_planner.py` (min-conflicts) |
| **CO4** | Decision-making / **utility-based policy** under bounded computation | `core/decision.py` (active localization) |
| **CO5** | Uncertainty + **inference by sampling** for **tracking** | `core/localization.py` (Bayes/Markov) + `core/particle_filter.py` (particles) |
| **CO6** | Integrated pipeline with **explainable outputs** (traces, proofs) | reasoning traces in `simulation.py`, `decision.py`, and the CSP trace |

---

## 3. Tech stack

- **Backend:** Python 3.11–3.13, **FastAPI** (serves the API *and* the
  frontend, so one command runs everything), **NumPy** for the belief maths.
- **Database:** **SQLite** (a single `robot.db` file, auto-created).
- **Frontend:** plain **HTML + CSS + JavaScript** with the **Canvas** API. No
  build step, no CDN.

---

## 4. Folder structure

```
mobile_robot_localization/
├── backend/
│   ├── app/
│   │   ├── main.py               # FastAPI app + all routes + serves frontend
│   │   ├── database.py           # SQLite connection + schema
│   │   ├── models.py             # Pydantic request models (validation)
│   │   ├── repository.py         # SQL read/write helpers
│   │   └── core/
│   │       ├── grid.py           # grid world (cells, obstacles, neighbours)   CO1
│   │       ├── robot.py          # robot true position + movement              CO1
│   │       ├── sensors.py        # simulated noisy range sensors
│   │       ├── localization.py   # histogram / Bayes (Markov) filter           CO5
│   │       ├── particle_filter.py# particle (sampling) filter                  CO5
│   │       ├── planners.py       # BFS / DFS / UCS / Greedy / A*               CO2
│   │       ├── csp_planner.py    # CSP min-conflicts path planner              CO3
│   │       ├── csp_backtracking.py# backtracking CSP + MRV/LCV/AC-3            CO3
│   │       ├── decision.py       # active localization (utility policy)        CO4
│   │       └── simulation.py     # ties it together + reasoning trace          CO6
│   ├── tests/                    # 20 unit tests
│   └── requirements.txt
├── frontend/
│   ├── index.html
│   ├── css/styles.css
│   └── js/{api.js, canvas.js, app.js}
├── schema.sql
├── run.sh
└── README.md
```

---

## 5. Installation

**Important:** this project needs ready-made packages (especially **numpy**).
Brand-new Python releases (like **3.14**) often don't have those ready yet, so
your computer would try to *build* numpy from scratch and fail with errors about
a missing compiler. **Use Python 3.13** (or 3.11/3.12) and everything installs
instantly as pre-built files.

**Step 1 — get Python 3.13** if you don't have it: download it from
<https://www.python.org/downloads/> and, in the installer, tick **"Add
python.exe to PATH"**.

**Step 2 — open the project's `backend` folder in a terminal** and install:

```bash
cd backend
py -3.13 -m pip install -r requirements.txt
```

> On Mac/Linux use `python3.13` instead of `py -3.13`. If you only have one
> Python and it's 3.11/3.12/3.13, plain `pip install -r requirements.txt` is
> fine.

A virtual environment is optional. If you want one and it works on your machine:
`py -3.13 -m venv .venv` then activate it (`.venv\Scripts\activate` on Windows,
`source .venv/bin/activate` on Mac/Linux) before installing. If creating a venv
ever hangs (common when the folder is inside OneDrive), just skip it and install
directly as shown above.

---

## 6. Running the app

**Easiest (Windows) — double-click `run.bat`.** Open the `backend` folder in
File Explorer and **double-click `run.bat`**. A console window opens, starts the
server, and stays open. When it prints `Application startup complete`, open your
browser to **http://127.0.0.1:8000**.

**Or from a terminal**, in the `backend/` folder:

```bash
py -3.13 start.py
```

Both of these use `start.py`, which launches the server **without** the
`--reload` flag. Avoid `uvicorn app.main:app --reload` on Windows: the reload
feature spawns a helper process that can die on some setups and shut the whole
server down right after it starts (you'd see `Application startup complete`
immediately followed by `Shutting down`). `start.py` runs one stable process and
avoids that.

The auto-generated API docs are at **http://127.0.0.1:8000/docs**. The database
file `backend/robot.db` is created automatically. To stop the server, press
**Ctrl+C** in its window (or just close the window).

> Tip: run it in its **own console window** (double-clicking `run.bat`, or a
> normal PowerShell/Command Prompt) rather than relying on an editor's embedded
> terminal, which on some machines interferes with the server.

---

## 7. Using the web interface

- **Run simulation** — plans a path with the chosen planner and the chosen
  localization filter, then animates the robot, estimate, belief heatmap (and
  the particle cloud if you picked the particle filter).
- **Localization filter** dropdown — switch between Histogram (exact) and
  Particle (sampling) and compare the error and confidence.
- **Active localize (CO4)** — the robot starts with *no idea* where it is and
  repeatedly picks the move that best reduces its uncertainty until it's
  confident. Watch the belief collapse and read the decision reasons.
- **CSP: sensor channels (CO3)** — pick a channel count and click *Assign
  channels*; the backtracking solver colours each zone so neighbours never
  clash. Try 2 or 3 channels to see it fail (not enough colours), then 4 to
  succeed.
- **Compare planners** — runs all planners on the current map; see cost, nodes
  expanded and time side by side.
- **Edit map** — Obstacle/Start/Goal modes; click cells to redraw the world.
- **Reasoning trace (CO6)** — a plain-English log of each step's reasoning.
- **Live panel** — true X/Y, estimated X/Y, error, confidence, entropy, and the
  four sensor readings, updating every step.

---

## 8. API documentation

Base URL `http://127.0.0.1:8000`. All bodies are JSON.

| Method | Path | Purpose | CO |
|---|---|---|---|
| GET | `/api/health` | liveness check | — |
| GET | `/api/default-map` | the built-in example map | — |
| POST | `/api/plan` | plan a path with one algorithm | CO2/CO3 |
| POST | `/api/simulate` | plan + localize (returns frames + trace) | CO5/CO6 |
| POST | `/api/compare` | run every planner on one map | CO2 |
| POST | `/api/csp-zones` | backtracking CSP channel assignment | CO3 |
| POST | `/api/active-localization` | utility-based active localization | CO4 |
| POST/GET | `/api/maps`, `/api/maps/{id}` | save / list / get maps | — |
| GET | `/api/runs`, `/api/runs/{id}` | list / get past runs | — |

A **map payload** is `{ "grid": [[0,1,...],...], "start": [x,y], "goal": [x,y] }`
where `grid[y][x]` is `0` (free) or `1` (obstacle).

`/api/simulate` extra fields: `algorithm` (`BFS|DFS|UCS|GREEDY|ASTAR|
CSP_MINCONFLICTS`), `method` (`histogram|particle`), `noise_std`,
`motion_success`, `num_particles`, `seed`. It returns `frames` (each with
`true_pos`, `est_pos`, `sensors`, `error`, `confidence`, `entropy`, `belief`,
and `particles` for the particle filter), a `summary`, and a `trace`.

`/api/csp-zones` fields: `block` (zone size), `channels`. Returns the
`assignment`, the `zones`, `backtracks`, `assignments_tried`, and a `trace`.

`/api/active-localization` fields: `method`, `noise_std`, `motion_success`,
`num_particles`, `max_steps`, `seed`. Returns `frames`, a decision `trace`, and
a `summary`.

---

## 9. Database schema

Two tables, created automatically (full SQL in `schema.sql`):

- **`maps`** — `id, name, width, height, grid_json, start_json, goal_json,
  created_at`.
- **`runs`** — `id, algorithm, path_cost, nodes_expanded, plan_time_ms, steps,
  avg_error, final_error, summary_json, created_at`.

---

## 10. Testing

From `backend/`:

```bash
py -3.13 -m pytest -q
```

**20 tests** cover: the grid world; every planner (shortest-path optimality,
connected paths, no-path detection); the histogram filter (readings, belief
normalisation, low error); the particle filter (weight normalisation,
convergence); the backtracking CSP (valid colouring, failure with too few
channels, AC-3); and active localization (uncertainty goes down).

---

## 11. Code walkthrough — every file explained

Every file is also **heavily commented inline**. This section is the
bigger-picture tour.

### `core/grid.py` — the world (CO1)
`GridMap` dataclass: width/height, `grid[y][x]` of 0/1, start, goal. Validates
itself, and answers the questions search/localization ask constantly:
`in_bounds`, `is_free`, `neighbors` (free 4-connected cells), `free_cells`.
Uses `(x, y)` everywhere, which is what the UI shows as the robot's X and Y.

### `core/robot.py` — the robot's true state (CO1)
Holds the **true** position (unknown to the filters) so we can simulate sensors
and measure error. `can_move`/`move`/`move_to` apply movement, refusing to walk
into walls.

### `core/sensors.py` — simulated sensors
`RangeSensor` casts a ray UP/DOWN/LEFT/RIGHT and counts free cells to the first
wall (`true_reading`), then adds Gaussian noise (`noisy_reading`) to imitate a
real device.

### `core/localization.py` — histogram / Bayes (Markov) filter (CO5)
The exact discrete Bayes filter. `predict(action)` shifts the probability grid
in the move's direction (mass stays if blocked); `update(observation)` multiplies
in a Gaussian sensor likelihood per cell and re-normalises (Bayes' rule).
`estimated_position` is the argmax; `entropy` measures uncertainty (used by CO4).

### `core/particle_filter.py` — particle (sampling) filter (CO5)
Monte-Carlo localization. Hundreds of particles (sampled position guesses) are
**predicted** (moved with random slip), **weighted** by sensor likelihood, and
**resampled** (good ones kept, bad ones dropped) whenever the effective sample
size drops. Same interface as the histogram filter, so the simulation treats
both identically — only the maths differs.

### `core/planners.py` — search (CO2)
A shared `SearchResult` plus BFS (FIFO queue), DFS (stack), UCS (priority queue
on `g`), Greedy (priority queue on `h`), and A* (`f = g + h`). The only
difference between them is the data structure that orders the frontier — which is
exactly the CO2 lesson. `manhattan` is the admissible heuristic.

### `core/csp_planner.py` — CSP min-conflicts (CO3)
Path-as-CSP solved by **local search**: hold a full candidate path and
repeatedly reassign the most-conflicted cell to its least-conflicting value. On
failure it **explains the violated constraint** (CO6).

### `core/csp_backtracking.py` — backtracking CSP (CO3)
A general `CSP` class solved by **backtracking** with **MRV** (fewest values
first), the **degree** tie-break, **LCV** (least-constraining value), and
**forward checking**, plus **AC-3** propagation. Applied to a robot **resource
task**: assign sensor channels to map zones so neighbouring zones differ
(graph-colouring). Every assignment, prune and backtrack is recorded as a
**reasoning trace** (CO6). Too few channels => it correctly reports failure.

### `core/decision.py` — active localization (CO4)
A **utility-based policy**: at each step it scores every move by how much it
would *separate* the robot's likely positions (so the next sensor reading
disambiguates them) and picks the best one. `run_active_localization` runs this
loop from a uniform belief until the robot is confident, logging *why* each move
was chosen (CO6).

### `core/simulation.py` — the conductor (CO6)
`make_filter` builds the chosen filter; `run_simulation` plans a path, then for
each step runs predict -> sense -> update, records a **frame** (true/estimate,
sensors, error, confidence, entropy, belief, particles) and a short **reasoning
trace**. `compare_planners` runs every planner for the CO2 comparison.

### `database.py` / `models.py` / `repository.py` / `main.py`
SQLite setup; Pydantic request validation (and the `/docs` page); the SQL
helpers; and the FastAPI app that defines every route and also serves the
frontend so one command runs the whole project.

### `frontend/index.html` · `css/styles.css` · `js/*`
The dashboard page; the dark theme; and three scripts: `api.js` (fetch
wrappers), `canvas.js` (draws the grid, obstacles, path, belief heatmap,
particle cloud, robot, estimate, and the error chart), and `app.js` (the
controller: state, buttons/sliders, playback, map editing, and rendering the
summary, trace and CSP zones).

---

## 12. Suggested extra features

- **"Kidnapped robot"**: teleport the robot mid-run to show the belief recover
  (the particle filter handles this especially well).
- **Diagonal (8-connected) movement** with an octile heuristic.
- **Weighted terrain** so UCS/A* visibly beat BFS.
- **Side-by-side filter race**: histogram vs particle error on the same path.
- **Symmetric/ambiguous maps** to make active localization take many steps.
- **CSP scheduling variant**: assign robot tasks to time slots with precedence
  constraints, reusing the same backtracking solver.
- **Export** a run as JSON / the path as CSV.

> Viva note: this project now spans the **entire** syllabus. Localization sits on
> the **Markov-model + sampling inference** of CO5; the planners are CO2; the
> backtracking and min-conflicts CSPs are CO3; active localization is a CO4
> utility-based policy; and every pipeline emits the explainable traces CO6 asks
> for — all built on the Python state representations of CO1.
