/*
 * canvas.js
 * ---------
 * All the drawing logic lives here. The `Renderer` class knows how to paint:
 *   - the grid and obstacles,
 *   - the start and goal cells,
 *   - the belief heatmap (how sure the robot is about each cell),
 *   - the planned path,
 *   - the true robot position (filled dot) and the estimate (hollow ring).
 * It also draws the small "error per step" line chart.
 */

class Renderer {
  constructor(canvas) {
    this.canvas = canvas;
    this.ctx = canvas.getContext("2d");
  }

  // Convert a grid (x, y) to a pixel rectangle on the canvas.
  cellRect(x, y, cols, rows) {
    const cw = this.canvas.width / cols;
    const ch = this.canvas.height / rows;
    return { px: x * cw, py: y * ch, cw, ch };
  }

  // Translate a mouse click into the grid cell it landed on.
  cellFromEvent(evt, cols, rows) {
    const rect = this.canvas.getBoundingClientRect();
    // The canvas is scaled by CSS, so map screen pixels back to canvas pixels.
    const scaleX = this.canvas.width / rect.width;
    const scaleY = this.canvas.height / rect.height;
    const x = Math.floor(((evt.clientX - rect.left) * scaleX) / (this.canvas.width / cols));
    const y = Math.floor(((evt.clientY - rect.top) * scaleY) / (this.canvas.height / rows));
    return { x: Math.max(0, Math.min(cols - 1, x)), y: Math.max(0, Math.min(rows - 1, y)) };
  }

  // Main draw call. `state` holds everything we currently know.
  draw(state) {
    const { grid, start, goal, path, belief, truePos, estPos, showBelief, particles } = state;
    const rows = grid.length;
    const cols = grid[0].length;
    const ctx = this.ctx;
    ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);

    // 1. Belief heatmap (drawn first, underneath everything else).
    if (showBelief && belief) {
      let max = 0;
      for (const row of belief) for (const v of row) if (v > max) max = v;
      for (let y = 0; y < rows; y++) {
        for (let x = 0; x < cols; x++) {
          const p = belief[y][x] / (max || 1);
          if (p > 0.001) {
            const { px, py, cw, ch } = this.cellRect(x, y, cols, rows);
            ctx.fillStyle = `rgba(54, 194, 168, ${0.12 + 0.8 * p})`;
            ctx.fillRect(px, py, cw, ch);
          }
        }
      }
    }

    // 2. Grid lines + obstacles.
    for (let y = 0; y < rows; y++) {
      for (let x = 0; x < cols; x++) {
        const { px, py, cw, ch } = this.cellRect(x, y, cols, rows);
        if (grid[y][x] === 1) {
          ctx.fillStyle = "#46506a";
          ctx.fillRect(px, py, cw, ch);
        }
        ctx.strokeStyle = "rgba(255,255,255,0.05)";
        ctx.strokeRect(px, py, cw, ch);
      }
    }

    // 3. Particle cloud (each little dot is one hypothesis about the position).
    if (particles && particles.length) {
      ctx.fillStyle = "rgba(242, 176, 74, 0.55)";
      const { cw, ch } = this.cellRect(0, 0, cols, rows);
      for (const [x, y] of particles) {
        const jx = (Math.random() - 0.5) * cw * 0.6;
        const jy = (Math.random() - 0.5) * ch * 0.6;
        ctx.beginPath();
        ctx.arc(x * cw + cw / 2 + jx, y * ch + ch / 2 + jy, 1.8, 0, Math.PI * 2);
        ctx.fill();
      }
    }

    // 4. Planned path (thin connected line).
    if (path && path.length > 1) {
      ctx.strokeStyle = "rgba(77, 124, 255, 0.9)";
      ctx.lineWidth = 3;
      ctx.beginPath();
      path.forEach(([x, y], i) => {
        const { px, py, cw, ch } = this.cellRect(x, y, cols, rows);
        const cx = px + cw / 2, cy = py + ch / 2;
        if (i === 0) ctx.moveTo(cx, cy); else ctx.lineTo(cx, cy);
      });
      ctx.stroke();
    }

    // 5. Start and goal markers.
    this._marker(start, cols, rows, "#6fc36f", "S");
    this._marker(goal, cols, rows, "#e0563b", "G");

    // 6. Estimated position: a hollow amber ring.
    if (estPos) {
      const { px, py, cw, ch } = this.cellRect(estPos[0], estPos[1], cols, rows);
      ctx.strokeStyle = "#f2b04a";
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.arc(px + cw / 2, py + ch / 2, Math.min(cw, ch) * 0.34, 0, Math.PI * 2);
      ctx.stroke();
    }

    // 7. True robot position: a filled teal dot.
    if (truePos) {
      const { px, py, cw, ch } = this.cellRect(truePos[0], truePos[1], cols, rows);
      ctx.fillStyle = "#36c2a8";
      ctx.beginPath();
      ctx.arc(px + cw / 2, py + ch / 2, Math.min(cw, ch) * 0.26, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  _marker(cell, cols, rows, color, letter) {
    const { px, py, cw, ch } = this.cellRect(cell[0], cell[1], cols, rows);
    this.ctx.fillStyle = color;
    this.ctx.globalAlpha = 0.85;
    this.ctx.fillRect(px + 2, py + 2, cw - 4, ch - 4);
    this.ctx.globalAlpha = 1;
    this.ctx.fillStyle = "#0f1420";
    this.ctx.font = `bold ${Math.floor(ch * 0.5)}px sans-serif`;
    this.ctx.textAlign = "center";
    this.ctx.textBaseline = "middle";
    this.ctx.fillText(letter, px + cw / 2, py + ch / 2);
  }
}

// A standalone helper that draws the localization-error line chart.
function drawErrorChart(canvas, errors, currentStep) {
  const ctx = canvas.getContext("2d");
  const W = canvas.width, H = canvas.height;
  ctx.clearRect(0, 0, W, H);
  if (!errors.length) return;

  const pad = 24;
  const maxErr = Math.max(2, ...errors);
  const stepX = (W - pad * 2) / Math.max(1, errors.length - 1);
  const scaleY = (H - pad * 2) / maxErr;

  // axes
  ctx.strokeStyle = "rgba(255,255,255,0.15)";
  ctx.beginPath();
  ctx.moveTo(pad, H - pad); ctx.lineTo(W - pad, H - pad);
  ctx.moveTo(pad, pad); ctx.lineTo(pad, H - pad);
  ctx.stroke();
  ctx.fillStyle = "#8a98b0";
  ctx.font = "10px sans-serif";
  ctx.textAlign = "right";
  ctx.fillText(maxErr.toFixed(0), pad - 4, pad + 4);
  ctx.fillText("0", pad - 4, H - pad);

  // error line
  ctx.strokeStyle = "#f2b04a";
  ctx.lineWidth = 2;
  ctx.beginPath();
  errors.forEach((e, i) => {
    const x = pad + i * stepX;
    const y = H - pad - e * scaleY;
    if (i === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
  });
  ctx.stroke();

  // marker for the current step
  if (currentStep >= 0 && currentStep < errors.length) {
    const x = pad + currentStep * stepX;
    const y = H - pad - errors[currentStep] * scaleY;
    ctx.fillStyle = "#36c2a8";
    ctx.beginPath();
    ctx.arc(x, y, 4, 0, Math.PI * 2);
    ctx.fill();
  }
}
