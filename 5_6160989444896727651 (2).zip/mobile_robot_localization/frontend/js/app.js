/*
 * app.js
 * ------
 * The "controller". Holds the current map + simulation state, wires up all the
 * buttons/sliders, talks to the backend through API, and drives the Renderer.
 */

const state = {
  grid: [],
  start: [0, 0],
  goal: [0, 0],
  path: null,
  frames: [],
  frameIndex: 0,
  errors: [],
  showBelief: true,
  editMode: "obstacle",
  playing: false,
  timer: null,
};

const $ = (id) => document.getElementById(id);
const renderer = new Renderer($("map"));
const errorCanvas = $("errorChart");

// ---- read the control values into one options object ----
function opts() {
  const seedRaw = $("seed").value;
  return {
    algorithm: $("algorithm").value,
    method: $("method").value,
    noise_std: parseFloat($("noise").value),
    motion_success: parseFloat($("motion").value),
    num_particles: parseInt($("particles").value, 10),
    seed: seedRaw === "" ? null : parseInt(seedRaw, 10),
  };
}

function currentMap() {
  return { grid: state.grid, start: state.start, goal: state.goal, name: "ui" };
}

// ---- rendering ----
function render() {
  const frame = state.frames[state.frameIndex];
  renderer.draw({
    grid: state.grid,
    start: state.start,
    goal: state.goal,
    path: state.path,
    belief: frame ? frame.belief : null,
    particles: frame ? frame.particles : null,
    truePos: frame ? frame.true_pos : null,
    estPos: frame ? frame.est_pos : null,
    showBelief: state.showBelief,
  });
  drawErrorChart(errorCanvas, state.errors, state.frameIndex);
  updateReadout(frame);
}

function updateReadout(frame) {
  if (!frame) {
    $("truePos").textContent = `${state.start[0]}, ${state.start[1]}`;
    ["estPos", "error", "confidence", "entropy"].forEach((id) => ($(id).textContent = "-"));
    $("step").textContent = `0 / 0`;
    ["UP", "DOWN", "LEFT", "RIGHT"].forEach((d) => ($("s" + d).textContent = "-"));
    return;
  }
  $("truePos").textContent = `${frame.true_pos[0]}, ${frame.true_pos[1]}`;
  $("estPos").textContent = `${frame.est_pos[0]}, ${frame.est_pos[1]}`;
  $("error").textContent = frame.error;
  $("confidence").textContent = `${Math.round(frame.confidence * 100)}%`;
  $("entropy").textContent = frame.entropy != null ? frame.entropy.toFixed(2) : "-";
  $("step").textContent = `${frame.step} / ${state.frames.length - 1}`;
  ["UP", "DOWN", "LEFT", "RIGHT"].forEach((d) => ($("s" + d).textContent = frame.sensors[d]));
}

function renderTrace(trace) {
  if (!trace || !trace.length) { $("trace").textContent = "(no trace)"; return; }
  $("trace").innerHTML = trace
    .map((t) => `<div><b>step ${t.step}:</b> ${t.text}</div>`)
    .join("");
}

// ---- playback ----
function showFrame(i) {
  state.frameIndex = Math.max(0, Math.min(state.frames.length - 1, i));
  render();
}
function play() {
  if (state.frames.length < 2) return;
  state.playing = true;
  $("playBtn").textContent = "Pause";
  state.timer = setInterval(() => {
    if (state.frameIndex >= state.frames.length - 1) return pause();
    showFrame(state.frameIndex + 1);
  }, 350);
}
function pause() {
  state.playing = false;
  $("playBtn").textContent = "Play";
  clearInterval(state.timer);
}

function loadFrames(res, path) {
  state.frames = res.frames;
  state.errors = res.frames.map((f) => f.error);
  state.path = path || null;
  state.frameIndex = 0;
  renderTrace(res.trace);
  ["playBtn", "stepFwd", "stepBack"].forEach((id) => ($(id).disabled = false));
  render();
}

// ---- backend actions ----
async function runSimulation() {
  pause();
  $("message").textContent = "Running...";
  try {
    const res = await API.simulate(currentMap(), opts());
    if (!res.success) {
      $("message").textContent = res.message || "No path found.";
      state.frames = []; state.path = null; state.errors = []; render();
      return;
    }
    $("message").textContent = res.message || "";
    renderSummary(res.summary);
    loadFrames(res, res.plan.path);
  } catch (err) {
    $("message").textContent = "Error: " + err.message;
  }
}

async function runActive() {
  pause();
  $("message").textContent = "Active localizing...";
  try {
    const res = await API.activeLocalization(currentMap(), opts());
    $("message").textContent = res.message || "";
    const s = res.summary;
    $("summary").innerHTML = `
      <div><span>Mode</span><b>Active localization</b></div>
      <div><span>Steps taken</span><b>${s.steps}</b></div>
      <div><span>Localized?</span><b>${s.localized ? "yes" : "not yet"}</b></div>
      <div><span>Final error</span><b>${s.final_error}</b></div>
      <div><span>Final confidence</span><b>${Math.round(s.final_confidence * 100)}%</b></div>`;
    loadFrames(res, null);  // no fixed path in active mode
  } catch (err) {
    $("message").textContent = "Error: " + err.message;
  }
}

function renderSummary(s) {
  $("summary").innerHTML = `
    <div><span>Planner</span><b>${s.algorithm}</b></div>
    <div><span>Filter</span><b>${s.method}</b></div>
    <div><span>Path cost</span><b>${s.path_cost}</b></div>
    <div><span>Nodes expanded</span><b>${s.nodes_expanded}</b></div>
    <div><span>Avg loc. error</span><b>${s.avg_localization_error}</b></div>
    <div><span>Final confidence</span><b>${Math.round(s.final_confidence * 100)}%</b></div>`;
}

async function compareAll() {
  $("compare").innerHTML = "Running all planners...";
  try {
    const res = await API.compare(currentMap(), 1);
    const rows = res.results.map((r) => `
      <tr class="${r.success ? "" : "fail"}">
        <td>${r.algorithm}</td><td>${r.success ? r.cost : "—"}</td>
        <td>${r.nodes_expanded}</td><td>${r.time_ms}</td></tr>`).join("");
    $("compare").innerHTML =
      `<table><thead><tr><th>Algorithm</th><th>Cost</th><th>Expanded</th><th>ms</th></tr></thead>
       <tbody>${rows}</tbody></table>`;
  } catch (err) {
    $("compare").textContent = "Error: " + err.message;
  }
}

const CHANNEL_COLORS = ["#36c2a8", "#f2b04a", "#4d7cff", "#e0563b", "#a36ad6", "#6fc36f"];

async function assignChannels() {
  $("cspResult").innerHTML = "Solving CSP...";
  try {
    const channels = parseInt($("channels").value, 10);
    const res = await API.cspZones(currentMap(), channels);
    let html = `<p class="note">${res.note}</p>
      <p class="hint">Tried ${res.assignments_tried} assignments, ${res.backtracks} backtracks.</p>`;
    if (res.success) {
      // little grid of zones coloured by their assigned channel
      const zones = Object.entries(res.zones);
      const maxBx = Math.max(...zones.map(([, z]) => z.bx));
      const maxBy = Math.max(...zones.map(([, z]) => z.by));
      let cells = "";
      for (let by = 0; by <= maxBy; by++) {
        for (let bx = 0; bx <= maxBx; bx++) {
          const entry = zones.find(([, z]) => z.bx === bx && z.by === by);
          const ch = entry ? res.assignment[entry[0]] : 0;
          cells += `<div class="zone" style="background:${CHANNEL_COLORS[ch % CHANNEL_COLORS.length]}">${ch}</div>`;
        }
      }
      html += `<div class="zones" style="grid-template-columns:repeat(${maxBx + 1},1fr)">${cells}</div>`;
    }
    $("cspResult").innerHTML = html;
  } catch (err) {
    $("cspResult").textContent = "Error: " + err.message;
  }
}

// ---- map editing ----
function resetPlayback() {
  pause();
  state.frames = []; state.path = null; state.errors = []; state.frameIndex = 0;
  ["playBtn", "stepFwd", "stepBack"].forEach((id) => ($(id).disabled = true));
  $("summary").innerHTML = ""; $("message").textContent = "";
  $("trace").textContent = "Run a simulation to see the step-by-step reasoning.";
  render();
}

function handleCanvasClick(evt) {
  const cols = state.grid[0].length, rows = state.grid.length;
  const { x, y } = renderer.cellFromEvent(evt, cols, rows);
  if (state.editMode === "obstacle") {
    if ((x === state.start[0] && y === state.start[1]) ||
        (x === state.goal[0] && y === state.goal[1])) return;
    state.grid[y][x] = state.grid[y][x] === 1 ? 0 : 1;
  } else if (state.editMode === "start") {
    state.grid[y][x] = 0; state.start = [x, y];
  } else if (state.editMode === "goal") {
    state.grid[y][x] = 0; state.goal = [x, y];
  }
  resetPlayback();
}

async function loadDefaultMap() {
  const m = await API.defaultMap();
  state.grid = m.grid; state.start = m.start; state.goal = m.goal;
  resetPlayback();
}

// ---- wire up ----
function init() {
  $("runBtn").onclick = runSimulation;
  $("activeBtn").onclick = runActive;
  $("playBtn").onclick = () => (state.playing ? pause() : play());
  $("stepFwd").onclick = () => { pause(); showFrame(state.frameIndex + 1); };
  $("stepBack").onclick = () => { pause(); showFrame(state.frameIndex - 1); };
  $("resetBtn").onclick = () => showFrame(0);
  $("newMap").onclick = loadDefaultMap;
  $("clearMap").onclick = () => {
    state.grid = state.grid.map((row) => row.map(() => 0));
    resetPlayback();
  };
  $("compareBtn").onclick = compareAll;
  $("cspBtn").onclick = assignChannels;

  $("noise").oninput = (e) => ($("noiseVal").textContent = e.target.value);
  $("motion").oninput = (e) => ($("motionVal").textContent = e.target.value);
  $("particles").oninput = (e) => ($("particleVal").textContent = e.target.value);
  $("channels").oninput = (e) => ($("channelVal").textContent = e.target.value);
  $("showBelief").onchange = (e) => { state.showBelief = e.target.checked; render(); };

  document.querySelectorAll(".mode").forEach((btn) => {
    btn.onclick = () => {
      document.querySelectorAll(".mode").forEach((b) => b.classList.remove("active"));
      btn.classList.add("active");
      state.editMode = btn.dataset.mode;
    };
  });

  $("map").addEventListener("click", handleCanvasClick);
  loadDefaultMap();
}

window.addEventListener("DOMContentLoaded", init);
