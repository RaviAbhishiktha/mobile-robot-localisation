/*
 * api.js
 * ------
 * Thin wrappers around the backend JSON API. Every function returns a Promise
 * that resolves to the parsed JSON response. Keeping all `fetch` calls here
 * means the rest of the frontend never touches URLs directly.
 */

const API = {
  // Generic POST helper: send a JS object as JSON, get JSON back.
  async post(path, body) {
    const res = await fetch(path, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    if (!res.ok) {
      const detail = await res.text();
      throw new Error(`${res.status}: ${detail}`);
    }
    return res.json();
  },

  async get(path) {
    const res = await fetch(path);
    if (!res.ok) throw new Error(`${res.status}`);
    return res.json();
  },

  // The example map the app loads on startup.
  defaultMap() {
    return API.get("/api/default-map");
  },

  // Plan a path only (no localization simulation).
  plan(map, algorithm, seed) {
    return API.post("/api/plan", { map, algorithm, seed });
  },

  // Plan + simulate localization; returns frames + summary + trace.
  simulate(map, opts) {
    return API.post("/api/simulate", {
      map,
      algorithm: opts.algorithm,
      method: opts.method,
      noise_std: opts.noise_std,
      motion_success: opts.motion_success,
      num_particles: opts.num_particles,
      seed: opts.seed,
      save: true,
    });
  },

  // Run the CO4 active-localization decision loop.
  activeLocalization(map, opts) {
    return API.post("/api/active-localization", {
      map,
      method: opts.method,
      noise_std: opts.noise_std,
      motion_success: opts.motion_success,
      num_particles: opts.num_particles,
      max_steps: 25,
      seed: opts.seed,
    });
  },

  // Solve the CO3 backtracking channel-assignment CSP.
  cspZones(map, channels) {
    return API.post("/api/csp-zones", { map, block: 4, channels });
  },

  // Run every planner on one map.
  compare(map, seed) {
    return API.post("/api/compare", { map, seed });
  },

  // Persist a map to the database.
  saveMap(map) {
    return API.post("/api/maps", map);
  },
};
