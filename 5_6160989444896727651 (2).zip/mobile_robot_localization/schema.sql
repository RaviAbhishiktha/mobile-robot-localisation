-- schema.sql
-- Reference copy of the database schema. The backend creates these tables
-- automatically on startup (see backend/app/database.py), so you do NOT need
-- to run this file by hand. It is provided for documentation.

CREATE TABLE IF NOT EXISTS maps (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    name       TEXT NOT NULL,
    width      INTEGER NOT NULL,
    height     INTEGER NOT NULL,
    grid_json  TEXT NOT NULL,      -- the 2D grid as JSON
    start_json TEXT NOT NULL,      -- [x, y]
    goal_json  TEXT NOT NULL,      -- [x, y]
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS runs (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    algorithm       TEXT NOT NULL,
    path_cost       INTEGER,
    nodes_expanded  INTEGER,
    plan_time_ms    REAL,
    steps           INTEGER,
    avg_error       REAL,
    final_error     INTEGER,
    summary_json    TEXT NOT NULL,  -- full summary dict as JSON
    created_at      TEXT DEFAULT CURRENT_TIMESTAMP
);
