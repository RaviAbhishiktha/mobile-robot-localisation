"""
models.py
=========
The "shapes" of the data that flows in and out of the API.

These are Pydantic models. FastAPI uses them to:
  - automatically validate incoming JSON (wrong types -> clear 422 error), and
  - generate the interactive API docs at /docs.
"""

from __future__ import annotations

from typing import List, Optional

from pydantic import BaseModel, Field


class MapPayload(BaseModel):
    """A grid map as sent by the frontend."""
    grid: List[List[int]] = Field(..., description="2D array of 0 (free) / 1 (obstacle)")
    start: List[int] = Field(..., description="[x, y] start cell")
    goal: List[int] = Field(..., description="[x, y] goal cell")
    name: Optional[str] = Field(default="untitled", description="optional map name")


class PlanRequest(BaseModel):
    """Ask the server to plan a path on a map with one algorithm."""
    map: MapPayload
    algorithm: str = Field(default="ASTAR",
                           description="BFS | DFS | UCS | GREEDY | ASTAR | CSP_MINCONFLICTS")
    seed: Optional[int] = Field(default=None, description="random seed for reproducibility")


class SimulateRequest(BaseModel):
    """Ask the server to plan AND simulate localization along the path."""
    map: MapPayload
    algorithm: str = Field(default="ASTAR")
    method: str = Field(default="histogram",
                        description="localization filter: histogram | particle")
    noise_std: float = Field(default=0.6, ge=0.0, le=5.0,
                             description="sensor noise standard deviation")
    motion_success: float = Field(default=0.85, ge=0.1, le=1.0,
                                  description="probability a commanded move succeeds")
    num_particles: int = Field(default=300, ge=50, le=2000,
                               description="particle count (particle filter only)")
    seed: Optional[int] = Field(default=None)
    save: bool = Field(default=True, description="store this run in the database")


class CompareRequest(BaseModel):
    """Run every planner on the same map for a side-by-side comparison."""
    map: MapPayload
    seed: Optional[int] = Field(default=None)


class CspZonesRequest(BaseModel):
    """Solve the channel-assignment CSP (CO3 backtracking) for a map."""
    map: MapPayload
    block: int = Field(default=4, ge=2, le=10, description="zone size in cells")
    channels: int = Field(default=4, ge=2, le=8, description="number of channels")


class ActiveLocalizationRequest(BaseModel):
    """Run the CO4 active-localization decision loop."""
    map: MapPayload
    method: str = Field(default="histogram")
    noise_std: float = Field(default=0.6, ge=0.0, le=5.0)
    motion_success: float = Field(default=0.85, ge=0.1, le=1.0)
    num_particles: int = Field(default=300, ge=50, le=2000)
    max_steps: int = Field(default=25, ge=3, le=80)
    seed: Optional[int] = Field(default=None)
