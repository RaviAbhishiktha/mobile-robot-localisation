"""
main.py
=======
The web server. Run it with:

    uvicorn app.main:app --reload   (from inside the backend/ folder)

It exposes a small JSON API (see the endpoints below) AND serves the
HTML/CSS/JS frontend, so a single command runs the whole project.
Interactive API docs are auto-generated at  http://127.0.0.1:8000/docs
"""

from __future__ import annotations

from pathlib import Path

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

from . import repository
from .core.csp_backtracking import solve_zone_assignment
from .core.decision import run_active_localization
from .core.grid import GridMap
from .core.simulation import compare_planners, plan_path, run_simulation
from .database import init_db
from .models import (ActiveLocalizationRequest, CompareRequest, CspZonesRequest,
                     MapPayload, PlanRequest, SimulateRequest)

# Where the frontend files live (../../frontend relative to this file).
FRONTEND_DIR = Path(__file__).resolve().parent.parent.parent / "frontend"

app = FastAPI(
    title="Mobile Robot Localization API",
    version="1.0.0",
    description="Grid-based localization + search/CSP path planning "
                "(Computational Foundations for AI project).",
)

# Allow the browser frontend to call the API during development.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


# Create the database tables right away (at import time) so the app works no
# matter how it is launched. We also keep the startup hook as a safety net.
init_db()


@app.on_event("startup")
def _startup() -> None:
    """Make sure the database tables exist before we serve any request."""
    init_db()


# --------------------------------------------------------------------- #
# A built-in example map so the UI has something to show immediately.
# --------------------------------------------------------------------- #
def default_map() -> dict:
    """A 12x10 grid with a few obstacle walls, a start and a goal."""
    width, height = 12, 10
    grid = [[0] * width for _ in range(height)]
    walls = [
        (3, 1), (3, 2), (3, 3), (3, 4),
        (7, 5), (7, 6), (7, 7), (7, 8),
        (5, 3), (6, 3), (8, 2), (9, 2),
        (1, 6), (2, 6), (2, 7),
    ]
    for (x, y) in walls:
        grid[y][x] = 1
    return {"grid": grid, "start": [0, 0], "goal": [11, 9], "name": "default"}


def _build_grid(payload: MapPayload) -> GridMap:
    """Turn an incoming MapPayload into a validated GridMap (or HTTP 400)."""
    try:
        return GridMap.from_dict(payload.model_dump())
    except Exception as exc:  # validation errors -> friendly 400
        raise HTTPException(status_code=400, detail=f"Invalid map: {exc}") from exc


# ============================== API ================================== #
@app.get("/api/health")
def health() -> dict:
    """Quick check that the server is alive."""
    return {"status": "ok"}


@app.get("/api/default-map")
def get_default_map() -> dict:
    """The example map the frontend loads on startup."""
    return default_map()


@app.post("/api/plan")
def api_plan(req: PlanRequest) -> dict:
    """Plan a path with one algorithm and return the path + statistics."""
    grid = _build_grid(req.map)
    result = plan_path(grid, req.algorithm, seed=req.seed)
    return result.to_dict()


@app.post("/api/simulate")
def api_simulate(req: SimulateRequest) -> dict:
    """Plan + simulate localization. Returns animation frames and a summary."""
    grid = _build_grid(req.map)
    result = run_simulation(
        grid,
        algorithm=req.algorithm,
        method=req.method,
        noise_std=req.noise_std,
        motion_success=req.motion_success,
        num_particles=req.num_particles,
        seed=req.seed,
    )
    if result["success"] and req.save:
        run_id = repository.save_run(result["summary"])
        result["run_id"] = run_id
    return result


@app.post("/api/csp-zones")
def api_csp_zones(req: CspZonesRequest) -> dict:
    """CO3: assign non-interfering channels to map zones via backtracking CSP."""
    grid = _build_grid(req.map)
    return solve_zone_assignment(grid, block=req.block, channels=req.channels)


@app.post("/api/active-localization")
def api_active_localization(req: ActiveLocalizationRequest) -> dict:
    """CO4: run the utility-based active-localization decision loop."""
    grid = _build_grid(req.map)
    return run_active_localization(
        grid,
        method=req.method,
        noise_std=req.noise_std,
        motion_success=req.motion_success,
        num_particles=req.num_particles,
        max_steps=req.max_steps,
        seed=req.seed,
    )


@app.post("/api/compare")
def api_compare(req: CompareRequest) -> dict:
    """Run every planner on one map for a side-by-side comparison."""
    grid = _build_grid(req.map)
    return {"results": compare_planners(grid, seed=req.seed)}


@app.post("/api/maps")
def api_save_map(payload: MapPayload) -> dict:
    """Persist a map to the database."""
    grid = _build_grid(payload)
    map_id = repository.save_map(
        payload.name or "untitled", grid.width, grid.height,
        grid.grid, list(grid.start), list(grid.goal),
    )
    return {"id": map_id}


@app.get("/api/maps")
def api_list_maps() -> dict:
    return {"maps": repository.list_maps()}


@app.get("/api/maps/{map_id}")
def api_get_map(map_id: int) -> dict:
    data = repository.get_map(map_id)
    if data is None:
        raise HTTPException(status_code=404, detail="map not found")
    return data


@app.get("/api/runs")
def api_list_runs() -> dict:
    return {"runs": repository.list_runs()}


@app.get("/api/runs/{run_id}")
def api_get_run(run_id: int) -> dict:
    data = repository.get_run(run_id)
    if data is None:
        raise HTTPException(status_code=404, detail="run not found")
    return data


# ============================ frontend =============================== #
# Serve static assets (css/js) and the index page. This block is last so it
# never shadows the /api routes above.
if FRONTEND_DIR.exists():
    app.mount("/css", StaticFiles(directory=FRONTEND_DIR / "css"), name="css")
    app.mount("/js", StaticFiles(directory=FRONTEND_DIR / "js"), name="js")

    @app.get("/")
    def index() -> FileResponse:
        return FileResponse(FRONTEND_DIR / "index.html")
