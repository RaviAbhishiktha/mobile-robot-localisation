"""
sensors.py
==========
Simulated range sensors (think: 4 little distance sensors pointing
UP, DOWN, LEFT and RIGHT, like a cheap ultrasonic / LiDAR setup).

For a given cell, each sensor reports how many free cells there are
between the robot and the first obstacle/wall in that direction.

Real sensors are noisy, so we offer a `noisy_reading` that adds a small
random error drawn from a Gaussian (bell-curve) distribution. The
localization algorithm later has to cope with this noise.
"""

from __future__ import annotations

from typing import Dict, List

import numpy as np

from .grid import Cell, GridMap, MOVES_4

# Sensors fire in the same four directions the robot can move.
SENSOR_DIRECTIONS: List[str] = ["UP", "DOWN", "LEFT", "RIGHT"]


class RangeSensor:
    """
    Casts a "ray" in each direction and counts free cells until blocked.

    Parameters
    ----------
    grid_map   : the world to measure against.
    noise_std  : standard deviation of the Gaussian sensor noise
                 (0 = perfect sensor, larger = noisier).
    max_range  : sensors stop counting after this many cells.
    rng        : a NumPy random generator (lets us reproduce runs with a seed).
    """

    def __init__(
        self,
        grid_map: GridMap,
        noise_std: float = 0.6,
        max_range: int = 10,
        rng: "np.random.Generator | None" = None,
    ) -> None:
        self.grid_map = grid_map
        self.noise_std = float(noise_std)
        self.max_range = int(max_range)
        self.rng = rng if rng is not None else np.random.default_rng()

    def true_reading(self, cell: Cell) -> Dict[str, int]:
        """
        The *exact* distances from `cell` to the nearest blockage in each
        direction, with no noise. Used both to simulate the sensor and to
        predict what each candidate cell *should* read during localization.
        """
        readings: Dict[str, int] = {}
        for name in SENSOR_DIRECTIONS:
            dx, dy = MOVES_4[name]
            distance = 0
            x, y = cell
            # Step outward until we leave the grid or hit an obstacle,
            # or until we reach the sensor's maximum range.
            while distance < self.max_range:
                x += dx
                y += dy
                if not self.grid_map.is_free((x, y)):
                    break
                distance += 1
            readings[name] = distance
        return readings

    def noisy_reading(self, cell: Cell) -> Dict[str, float]:
        """
        Like `true_reading`, but every value is corrupted with Gaussian
        noise to imitate a real-world sensor. Values are clamped to >= 0.
        """
        truth = self.true_reading(cell)
        noisy: Dict[str, float] = {}
        for name, value in truth.items():
            error = self.rng.normal(0.0, self.noise_std)
            noisy[name] = max(0.0, round(value + error, 3))
        return noisy
