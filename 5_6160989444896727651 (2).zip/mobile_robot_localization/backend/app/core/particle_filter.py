"""
particle_filter.py
==================
Particle-filter localization -- the *sampling-based* approach to the same
tracking problem solved exactly by the histogram filter (see localization.py).

WHY THIS IS IN THE SYLLABUS (CO5)
---------------------------------
CO5 asks us to "apply reasoning under uncertainty ... and perform inference
using algorithmic methods (variable elimination, **sampling**) for
diagnosis/**tracking** cases". A particle filter is exactly that: it represents
the belief about the robot's position with a *cloud of samples* (particles)
instead of a full probability grid, and updates them with the same predict /
weight / resample cycle that defines Monte-Carlo inference.

THE IDEA (plain words)
----------------------
Imagine throwing hundreds of guesses ("particles") about where the robot might
be. Each cycle:
  1. PREDICT  -- move every particle the way the robot moved (with a little
                 random slip, because motion is imperfect).
  2. WEIGHT   -- score each particle by how well its expected sensor reading
                 matches what we actually observed.
  3. RESAMPLE -- duplicate good particles and drop bad ones, so the cloud
                 concentrates where the robot probably is.

The histogram filter is exact but stores a number for every cell; the particle
filter is approximate but only tracks the cells that matter. Comparing the two
is a great way to *see* the time/accuracy trade-off the course talks about.
"""

from __future__ import annotations

import math
from typing import Dict, List, Tuple

import numpy as np

from .grid import Cell, GridMap, MOVES_4
from .sensors import RangeSensor, SENSOR_DIRECTIONS

EPS = 1e-12


class ParticleFilter:
    """Monte-Carlo (sampling) localization over a GridMap."""

    def __init__(
        self,
        grid_map: GridMap,
        sensor: RangeSensor,
        num_particles: int = 300,
        motion_success: float = 0.85,
        rng: "np.random.Generator | None" = None,
    ) -> None:
        self.grid_map = grid_map
        self.sensor = sensor
        self.num_particles = int(num_particles)
        self.motion_success = float(motion_success)
        self.rng = rng if rng is not None else np.random.default_rng()

        self.free = grid_map.free_cells()
        # Expected (noise-free) reading for every free cell, computed once.
        self._expected: Dict[Cell, Dict[str, int]] = {
            c: sensor.true_reading(c) for c in self.free
        }

        # Start: scatter particles uniformly over the free cells.
        idx = self.rng.integers(0, len(self.free), size=self.num_particles)
        self.particles: List[Cell] = [self.free[i] for i in idx]
        self.weights = np.ones(self.num_particles) / self.num_particles

    # ----------------------------------------------------------------- #
    # 1. PREDICT -- move every particle like the robot moved
    # ----------------------------------------------------------------- #
    def predict(self, action: str) -> None:
        dx, dy = MOVES_4[action]
        new_particles: List[Cell] = []
        for (x, y) in self.particles:
            r = self.rng.random()
            if r < self.motion_success:
                target = (x + dx, y + dy)                # intended move
                new_particles.append(target if self.grid_map.is_free(target) else (x, y))
            else:
                # Motion "slip": step to a random free neighbour, or stay.
                nbrs = self.grid_map.neighbors((x, y))
                new_particles.append(nbrs[self.rng.integers(len(nbrs))] if nbrs else (x, y))
        self.particles = new_particles

    # ----------------------------------------------------------------- #
    # 2. WEIGHT -- score particles by how well they explain the reading
    # ----------------------------------------------------------------- #
    def update(self, observation: Dict[str, float]) -> None:
        sigma = max(self.sensor.noise_std, 0.25)
        w = np.empty(self.num_particles)
        for i, cell in enumerate(self.particles):
            expected = self._expected.get(cell)
            if expected is None:           # particle drifted onto an obstacle
                w[i] = EPS
                continue
            log_like = 0.0
            for name in SENSOR_DIRECTIONS:
                diff = observation[name] - expected[name]
                log_like += -0.5 * (diff / sigma) ** 2
            w[i] = math.exp(log_like)
        total = w.sum()
        self.weights = (w / total) if total > EPS else np.ones(self.num_particles) / self.num_particles
        # Resample whenever the effective number of particles gets low.
        if self._effective_sample_size() < self.num_particles / 2:
            self._resample()

    def _effective_sample_size(self) -> float:
        """A measure of how many particles are 'doing useful work'."""
        return 1.0 / float(np.sum(self.weights ** 2) + EPS)

    def _resample(self) -> None:
        """Keep good particles, drop bad ones (systematic resampling)."""
        positions = (self.rng.random() + np.arange(self.num_particles)) / self.num_particles
        cumulative = np.cumsum(self.weights)
        new: List[Cell] = []
        i = 0
        for pos in positions:
            while i < len(cumulative) - 1 and pos > cumulative[i]:
                i += 1
            new.append(self.particles[i])
        self.particles = new
        self.weights = np.ones(self.num_particles) / self.num_particles

    # ----------------------------------------------------------------- #
    # Reading the belief
    # ----------------------------------------------------------------- #
    def _histogram(self) -> Dict[Cell, float]:
        """Total weight landing on each cell."""
        hist: Dict[Cell, float] = {}
        for cell, weight in zip(self.particles, self.weights):
            hist[cell] = hist.get(cell, 0.0) + float(weight)
        return hist

    def estimated_position(self) -> Cell:
        """The cell holding the most particle weight (the belief 'peak')."""
        hist = self._histogram()
        return max(hist.items(), key=lambda kv: kv[1])[0]

    def confidence(self) -> float:
        """Fraction of particles sitting on the estimated cell."""
        hist = self._histogram()
        return float(max(hist.values())) if hist else 0.0

    def entropy(self) -> float:
        """Uncertainty of the belief (high = spread out, low = confident)."""
        hist = self._histogram()
        h = 0.0
        for p in hist.values():
            if p > 0:
                h -= p * math.log(p + EPS)
        return h

    def belief_grid(self) -> List[List[float]]:
        """Particle density per cell, shaped like the grid (for the heatmap)."""
        grid = [[0.0] * self.grid_map.width for _ in range(self.grid_map.height)]
        for cell, weight in zip(self.particles, self.weights):
            grid[cell[1]][cell[0]] += float(weight)
        return [[round(v, 6) for v in row] for row in grid]

    def particle_points(self, limit: int = 200) -> List[List[int]]:
        """A sample of particle positions for drawing the cloud on screen."""
        pts = self.particles if len(self.particles) <= limit else self.particles[:limit]
        return [[c[0], c[1]] for c in pts]

    def top_cells(self, k: int = 5) -> List[Tuple[Cell, float]]:
        hist = self._histogram()
        ordered = sorted(hist.items(), key=lambda kv: kv[1], reverse=True)[:k]
        return [(c, round(p, 5)) for c, p in ordered]
