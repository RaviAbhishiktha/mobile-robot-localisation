"""
grid.py
=======
The "world" the robot lives in.

We model the environment as a 2D grid of square cells. Each cell is either:
    0  -> FREE     (the robot can stand here)
    1  -> OBSTACLE (a wall / blocked cell)

We use (x, y) coordinates everywhere:
    x = column index (horizontal, left -> right)
    y = row index    (vertical,   top  -> bottom)

The grid itself is stored as a list of rows, so the value of a cell is:
    grid[y][x]

This (x, y) convention is what we show the user as the robot's
"X coordinate" and "Y coordinate" in real time.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, List, Tuple

# A cell is just a pair of integers: (x, y).
Cell = Tuple[int, int]

# Human-readable names for the two cell values.
FREE: int = 0
OBSTACLE: int = 1

# The four moves a robot can make on a 4-connected grid.
# Key   = action name (used in logs and explanations)
# Value = (dx, dy) change applied to the robot's (x, y) position.
MOVES_4: Dict[str, Cell] = {
    "UP": (0, -1),     # decrease y -> move toward the top
    "DOWN": (0, 1),    # increase y -> move toward the bottom
    "LEFT": (-1, 0),   # decrease x -> move left
    "RIGHT": (1, 0),   # increase x -> move right
}


@dataclass
class GridMap:
    """
    A simple, validated 2D occupancy grid with a start and goal cell.

    Attributes
    ----------
    width  : number of columns (x ranges 0 .. width-1)
    height : number of rows    (y ranges 0 .. height-1)
    grid   : 2D list of 0/1 values, indexed as grid[y][x]
    start  : (x, y) cell where the robot begins
    goal   : (x, y) cell the robot is trying to reach
    """

    width: int
    height: int
    grid: List[List[int]]
    start: Cell
    goal: Cell

    def __post_init__(self) -> None:
        # Runs automatically right after the object is created.
        # We validate the data so the rest of the program can trust it.
        if self.height != len(self.grid):
            raise ValueError("height does not match number of rows in grid")
        for row in self.grid:
            if len(row) != self.width:
                raise ValueError("every row must have exactly `width` columns")
        for cell in (self.start, self.goal):
            if not self.in_bounds(cell):
                raise ValueError(f"cell {cell} is outside the grid")
        # Start and goal must be standable (not inside a wall).
        self.grid[self.start[1]][self.start[0]] = FREE
        self.grid[self.goal[1]][self.goal[0]] = FREE

    # ----------------------------------------------------------------- #
    # Small helper questions we ask about the grid all the time.
    # ----------------------------------------------------------------- #
    def in_bounds(self, cell: Cell) -> bool:
        """True if the cell is inside the grid rectangle."""
        x, y = cell
        return 0 <= x < self.width and 0 <= y < self.height

    def is_free(self, cell: Cell) -> bool:
        """True if the cell is inside the grid AND not an obstacle."""
        x, y = cell
        return self.in_bounds(cell) and self.grid[y][x] == FREE

    def neighbors(self, cell: Cell) -> List[Cell]:
        """
        Return the free, in-bounds cells directly UP/DOWN/LEFT/RIGHT
        of `cell`. These are the places the robot could step to next.
        """
        x, y = cell
        result: List[Cell] = []
        for dx, dy in MOVES_4.values():
            nxt = (x + dx, y + dy)
            if self.is_free(nxt):
                result.append(nxt)
        return result

    def free_cells(self) -> List[Cell]:
        """Return a list of every free cell in the grid."""
        cells: List[Cell] = []
        for y in range(self.height):
            for x in range(self.width):
                if self.grid[y][x] == FREE:
                    cells.append((x, y))
        return cells

    # ----------------------------------------------------------------- #
    # Convenience constructors
    # ----------------------------------------------------------------- #
    @classmethod
    def from_dict(cls, data: dict) -> "GridMap":
        """Build a GridMap from plain JSON-style data sent by the frontend."""
        grid = data["grid"]
        return cls(
            width=len(grid[0]),
            height=len(grid),
            grid=[list(row) for row in grid],          # copy, so we never mutate input
            start=tuple(data["start"]),                # type: ignore[arg-type]
            goal=tuple(data["goal"]),                  # type: ignore[arg-type]
        )

    def to_dict(self) -> dict:
        """Convert back to plain data for storing or sending as JSON."""
        return {
            "width": self.width,
            "height": self.height,
            "grid": self.grid,
            "start": list(self.start),
            "goal": list(self.goal),
        }
