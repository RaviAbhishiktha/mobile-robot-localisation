"""
csp_backtracking.py
===================
A general Constraint Satisfaction Problem (CSP) solver using **backtracking
search** with the classic heuristics from CO3, plus a worked robot example.

CO3 asks us to "model and solve CSPs using backtracking, propagation, and
heuristics (MRV/degree/LCV); evaluate solution quality for realistic
scheduling/**resource** tasks." So this file provides:

  * a reusable `CSP` class with:
      - MRV  (Minimum Remaining Values) variable ordering,
      - the degree heuristic as a tie-breaker,
      - LCV  (Least Constraining Value) value ordering,
      - Forward Checking, and
      - AC-3 arc-consistency propagation;
  * a worked **robot resource task**: assign non-interfering "sensor channels"
    to the zones of the map so that neighbouring zones never share a channel
    (this is graph-colouring, the textbook CSP, in robot clothing); and
  * a step-by-step **reasoning trace** (CO6) explaining every assignment,
    every pruning, and every backtrack -- a "constraint proof" you can read.
"""

from __future__ import annotations

from typing import Callable, Dict, List, Optional, Tuple

from .grid import GridMap

Assignment = Dict[str, int]


class CSP:
    """
    A finite-domain CSP solved by backtracking search.

    variables : list of variable names
    domains   : {variable: [possible values]}
    neighbors : {variable: [variables it shares a constraint with]}
    constraint: function(varA, valA, varB, valB) -> True if the pair is allowed
    """

    def __init__(
        self,
        variables: List[str],
        domains: Dict[str, List[int]],
        neighbors: Dict[str, List[str]],
        constraint: Callable[[str, int, str, int], bool],
    ) -> None:
        self.variables = variables
        self.domains = {v: list(domains[v]) for v in variables}
        self.neighbors = neighbors
        self.constraint = constraint
        self.trace: List[dict] = []      # human-readable reasoning steps (CO6)
        self.assignments_tried = 0
        self.backtracks = 0

    # ----- consistency check ------------------------------------------ #
    def _consistent(self, var: str, value: int, assignment: Assignment) -> bool:
        """Does giving `var = value` break any constraint with assigned neighbours?"""
        for other in self.neighbors[var]:
            if other in assignment and not self.constraint(var, value, other, assignment[other]):
                return False
        return True

    # ----- variable ordering: MRV + degree tie-break ------------------ #
    def _select_unassigned(self, assignment: Assignment, domains: Dict[str, List[int]]) -> str:
        unassigned = [v for v in self.variables if v not in assignment]
        # MRV: fewest legal values left. Tie-break: degree (most unassigned neighbours).
        def degree(v: str) -> int:
            return sum(1 for n in self.neighbors[v] if n not in assignment)
        return min(unassigned, key=lambda v: (len(domains[v]), -degree(v)))

    # ----- value ordering: LCV ---------------------------------------- #
    def _order_values(self, var: str, assignment: Assignment, domains: Dict[str, List[int]]) -> List[int]:
        """Least Constraining Value: try the value that removes fewest options
        from neighbouring variables first."""
        def conflicts(value: int) -> int:
            count = 0
            for other in self.neighbors[var]:
                if other not in assignment:
                    for ov in domains[other]:
                        if not self.constraint(var, value, other, ov):
                            count += 1
            return count
        return sorted(domains[var], key=conflicts)

    # ----- forward checking ------------------------------------------- #
    def _forward_check(self, var: str, value: int, assignment: Assignment,
                       domains: Dict[str, List[int]]) -> Optional[Dict[str, List[int]]]:
        """Remove now-impossible values from neighbours. Return the pruned
        domains, or None if some neighbour is left with no options."""
        pruned = {v: list(d) for v, d in domains.items()}
        for other in self.neighbors[var]:
            if other not in assignment:
                pruned[other] = [ov for ov in pruned[other] if self.constraint(var, value, other, ov)]
                if not pruned[other]:
                    self.trace.append({
                        "action": "prune-fail",
                        "detail": f"{other} has no legal channel after {var}={value}",
                    })
                    return None
        return pruned

    # ----- the recursive backtracking search -------------------------- #
    def backtracking_search(self, use_forward_checking: bool = True) -> Optional[Assignment]:
        self.trace = []
        self.assignments_tried = 0
        self.backtracks = 0
        return self._backtrack({}, self.domains)

    def _backtrack(self, assignment: Assignment, domains: Dict[str, List[int]]) -> Optional[Assignment]:
        if len(assignment) == len(self.variables):
            return dict(assignment)                       # all variables assigned -> solved

        var = self._select_unassigned(assignment, domains)
        for value in self._order_values(var, assignment, domains):
            self.assignments_tried += 1
            if self._consistent(var, value, assignment):
                assignment[var] = value
                self.trace.append({"action": "assign", "var": var, "value": value})
                pruned = self._forward_check(var, value, assignment, domains)
                if pruned is not None:
                    result = self._backtrack(assignment, pruned)
                    if result is not None:
                        return result
                # undo (backtrack)
                del assignment[var]
                self.backtracks += 1
                self.trace.append({"action": "backtrack", "var": var, "value": value})
        return None


# --------------------------------------------------------------------- #
# AC-3 propagation (constraint propagation, also part of CO3)
# --------------------------------------------------------------------- #
def ac3(csp: CSP) -> bool:
    """
    Make the CSP arc-consistent before/while searching. Returns False if a
    domain is emptied (meaning the problem is unsolvable as constrained).
    """
    queue: List[Tuple[str, str]] = [(xi, xj) for xi in csp.variables for xj in csp.neighbors[xi]]
    while queue:
        xi, xj = queue.pop(0)
        if _revise(csp, xi, xj):
            if not csp.domains[xi]:
                return False
            for xk in csp.neighbors[xi]:
                if xk != xj:
                    queue.append((xk, xi))
    return True


def _revise(csp: CSP, xi: str, xj: str) -> bool:
    """Remove values from xi's domain with no support in xj's domain."""
    revised = False
    for x in list(csp.domains[xi]):
        if not any(csp.constraint(xi, x, xj, y) for y in csp.domains[xj]):
            csp.domains[xi].remove(x)
            revised = True
    return revised


# --------------------------------------------------------------------- #
# The worked robot example: assign sensor channels to map zones
# --------------------------------------------------------------------- #
def build_zone_csp(grid_map: GridMap, block: int = 4, channels: int = 4) -> Tuple[CSP, dict]:
    """
    Split the map into rectangular zones and require neighbouring zones to use
    different "channels" (colours). This is a realistic robot resource task:
    nearby sensors must not share a frequency or they interfere.
    """
    cols = max(1, -(-grid_map.width // block))     # ceil division
    rows = max(1, -(-grid_map.height // block))

    variables: List[str] = []
    zone_cells: Dict[str, dict] = {}
    for by in range(rows):
        for bx in range(cols):
            name = f"Z{bx}{by}"
            variables.append(name)
            zone_cells[name] = {
                "x0": bx * block, "y0": by * block,
                "x1": min((bx + 1) * block, grid_map.width),
                "y1": min((by + 1) * block, grid_map.height),
                "bx": bx, "by": by,
            }

    # Two zones are neighbours if their blocks touch -- horizontally, vertically,
    # OR diagonally (king moves). Diagonal contact makes the constraint graph
    # non-trivial, so too-few channels genuinely fail and need backtracking.
    neighbors: Dict[str, List[str]] = {v: [] for v in variables}
    for a in variables:
        for b in variables:
            if a == b:
                continue
            za, zb = zone_cells[a], zone_cells[b]
            if abs(za["bx"] - zb["bx"]) <= 1 and abs(za["by"] - zb["by"]) <= 1:
                neighbors[a].append(b)

    domains = {v: list(range(channels)) for v in variables}
    csp = CSP(variables, domains, neighbors, constraint=lambda va, a, vb, b: a != b)
    meta = {"cols": cols, "rows": rows, "block": block, "channels": channels, "zones": zone_cells}
    return csp, meta


def solve_zone_assignment(grid_map: GridMap, block: int = 4, channels: int = 4) -> dict:
    """Solve the channel-assignment CSP and return the result + reasoning trace."""
    csp, meta = build_zone_csp(grid_map, block=block, channels=channels)
    ac3(csp)                                   # propagate first (tighten domains)
    solution = csp.backtracking_search()
    return {
        "success": solution is not None,
        "assignment": solution or {},
        "zones": meta["zones"],
        "channels": channels,
        "assignments_tried": csp.assignments_tried,
        "backtracks": csp.backtracks,
        "trace": csp.trace[:60],               # cap the trace for the UI
        "note": (
            f"Assigned {channels} channels to {len(csp.variables)} zones with "
            f"{csp.backtracks} backtracks."
            if solution else
            f"No valid assignment with only {channels} channels -- needs more."
        ),
    }
