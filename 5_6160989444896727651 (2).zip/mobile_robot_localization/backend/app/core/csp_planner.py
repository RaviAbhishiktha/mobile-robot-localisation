"""
csp_planner.py
==============
Robot navigation framed as a Constraint Satisfaction Problem and solved with
the Min-Conflicts local-search algorithm (CO3, Sessions 9 & 10).

CSP MODEL
---------
  Variables : the cells of a path  x0, x1, ..., x_{L-1}
  Domain    : every FREE cell of the grid
  Fixed     : x0 = start, x_{L-1} = goal
  Constraint: consecutive cells must be a single UP/DOWN/LEFT/RIGHT step apart,
              OR identical (a "stay"). Staying lets a short route pad itself out
              to the fixed length L, which makes the local search far more robust.

MIN-CONFLICTS (from the slide's pseudocode)
-------------------------------------------
  1. Start from a complete assignment (a full candidate path).
  2. While not solved and steps remain:
        - pick a random *conflicted* variable,
        - reassign it to the value that causes the FEWEST conflicts
          (ties broken toward the goal, which speeds convergence).
  3. If we run out of steps, report failure AND explain which constraint
     could not be satisfied ("explainability: why a constraint failed").

Min-conflicts is a *local search*: it always holds a full path and nudges it,
instead of building the path step-by-step like BFS/A*.
"""

from __future__ import annotations

import random
import time
from typing import List, Optional

from .grid import Cell, GridMap
from .planners import SearchResult, bfs, manhattan


def _step_ok(a: Cell, b: Cell) -> bool:
    """A legal consecutive pair: same cell (stay) or one step apart."""
    return manhattan(a, b) <= 1


def _collapse(path: List[Cell]) -> List[Cell]:
    """Remove consecutive duplicate cells (the 'stay' padding)."""
    out: List[Cell] = []
    for cell in path:
        if not out or out[-1] != cell:
            out.append(cell)
    return out


class RobotCSP:
    """Path-planning-as-CSP solved by Min-Conflicts local search."""

    def __init__(self, grid: GridMap, max_steps: int = 4000, seed: Optional[int] = None):
        self.grid = grid
        self.start = grid.start
        self.goal = grid.goal
        self.max_steps = max_steps
        self.random = random.Random(seed)
        self._free_neighbors = {c: grid.neighbors(c) for c in grid.free_cells()}

    # ----- building an initial complete assignment -------------------- #
    def initial_solution(self, length: int) -> List[Cell]:
        """
        Greedy first guess: from each cell step to the free neighbour closest to
        the goal. Once the goal is reached we 'stay' there to fill the length.
        This is a complete assignment that may still violate some constraints.
        """
        path: List[Cell] = [self.start]
        current = self.start
        for _ in range(length - 1):
            if current == self.goal:
                path.append(self.goal)        # stay on the goal
                continue
            neighbors = self._free_neighbors.get(current, [])
            if not neighbors:
                path.append(current)          # stuck: stay put
                continue
            neighbors = sorted(neighbors, key=lambda c: manhattan(c, self.goal))
            # Mostly greedy, occasionally random, to avoid always repeating a dead end.
            current = neighbors[0] if self.random.random() > 0.25 else self.random.choice(neighbors)
            path.append(current)
        path[0] = self.start
        path[-1] = self.goal
        return path

    # ----- counting constraint violations ----------------------------- #
    def conflicts_at(self, path: List[Cell], i: int) -> int:
        count = 0
        if i > 0 and not _step_ok(path[i - 1], path[i]):
            count += 1
        if i < len(path) - 1 and not _step_ok(path[i], path[i + 1]):
            count += 1
        return count

    def total_conflicts(self, path: List[Cell]) -> int:
        return sum(0 if _step_ok(path[i], path[i + 1]) else 1
                   for i in range(len(path) - 1))

    # ----- the Min-Conflicts loop ------------------------------------- #
    def min_conflicts(self) -> SearchResult:
        t0 = time.perf_counter()

        # BFS tells us the minimum number of cells a valid path needs. We give
        # the CSP some slack length so 'stay' padding has room to work.
        baseline = bfs(self.grid)
        if not baseline.success:
            return SearchResult(
                "CSP_MINCONFLICTS", False,
                note="Constraint failed: no adjacency-respecting path of free "
                     "cells connects start and goal (the goal is walled off).",
                time_ms=(time.perf_counter() - t0) * 1000,
            )
        shortest = len(baseline.path)
        length = shortest + max(6, shortest // 2)   # generous slack

        steps_used = 0
        restarts = 0
        path = self.initial_solution(length)

        while steps_used < self.max_steps:
            if self.total_conflicts(path) == 0:
                clean = _collapse(path)
                return SearchResult(
                    "CSP_MINCONFLICTS", True, path=clean,
                    cost=len(clean) - 1, nodes_expanded=steps_used, max_frontier=length,
                    time_ms=(time.perf_counter() - t0) * 1000,
                    note=f"Solved by Min-Conflicts in {steps_used} reassignments "
                         f"({restarts} restarts).",
                )

            conflicted = [i for i in range(1, length - 1) if self.conflicts_at(path, i) > 0]
            if not conflicted:
                # Only the fixed endpoints are in conflict -> restart.
                path = self.initial_solution(length)
                restarts += 1
                steps_used += 1
                continue

            # Min-conflicts heuristic: pick a random conflicted variable.
            i = self.random.choice(conflicted)
            prev = path[i - 1]
            # Candidate values keep the LEFT edge legal: stay on prev, or step
            # to one of prev's free neighbours.
            candidates = [prev] + self._free_neighbors.get(prev, [])

            best_val = path[i]
            best_key = (self.conflicts_at(path, i), manhattan(path[i], self.goal))
            self.random.shuffle(candidates)
            for v in candidates:
                path[i] = v
                # Rank by (fewest conflicts, then closeness to the goal).
                key = (self.conflicts_at(path, i), manhattan(v, self.goal))
                if key < best_key:
                    best_key, best_val = key, v
            path[i] = best_val
            steps_used += 1

            if steps_used % 600 == 0:           # periodic restart escapes minima
                path = self.initial_solution(length)
                restarts += 1

        return SearchResult(
            "CSP_MINCONFLICTS", False,
            nodes_expanded=steps_used, max_frontier=length,
            time_ms=(time.perf_counter() - t0) * 1000,
            note="Min-Conflicts hit the step limit without satisfying every "
                 "adjacency constraint. Local search is not complete; A* will "
                 "always find a path if one exists.",
        )


def csp_min_conflicts(grid: GridMap, seed: Optional[int] = None) -> SearchResult:
    """Convenience wrapper so the API can call the CSP planner like the others."""
    return RobotCSP(grid, seed=seed).min_conflicts()
