"""Core algorithms package: grid world, robot, sensors, localization, planners."""
