"""
simulation.py
=============
The conductor that ties planning + localization together and produces the
animation frames the frontend plays back.

It now supports BOTH localization methods from CO5:
  - "histogram" : the exact Markov/Bayes filter   (localization.py)
  - "particle"  : the sampling particle filter     (particle_filter.py)

and it records a short **reasoning trace** (CO6) describing what happened at
each step (predict -> sense -> update), so the pipeline is explainable.
"""

from __future__ import annotations

from typing import List, Optional

import numpy as np

from .csp_planner import csp_min_conflicts
from .grid import Cell, GridMap, MOVES_4
from .localization import GridLocalization
from .particle_filter import ParticleFilter
from .planners import PLANNERS, SearchResult, manhattan
from .robot import Robot
from .sensors import RangeSensor


def _action_between(a: Cell, b: Cell) -> Optional[str]:
    """The move name ('UP'..) that takes you from cell a to adjacent cell b."""
    dx, dy = b[0] - a[0], b[1] - a[1]
    for name, (mx, my) in MOVES_4.items():
        if (mx, my) == (dx, dy):
            return name
    return None


def make_filter(method: str, grid: GridMap, sensor: RangeSensor,
                motion_success: float, num_particles: int = 300,
                rng=None):
    """Build the chosen localization filter. Both share the same interface."""
    if method.lower() == "particle":
        return ParticleFilter(grid, sensor, num_particles=num_particles,
                              motion_success=motion_success, rng=rng)
    return GridLocalization(grid, sensor, motion_success=motion_success)


def plan_path(grid: GridMap, algorithm: str, seed: Optional[int] = None) -> SearchResult:
    """Run one planner by name and return its SearchResult."""
    algo = algorithm.upper()
    if algo == "CSP_MINCONFLICTS":
        return csp_min_conflicts(grid, seed=seed)
    if algo not in PLANNERS:
        raise ValueError(f"unknown algorithm '{algorithm}'")
    return PLANNERS[algo](grid)


def run_simulation(
    grid: GridMap,
    algorithm: str = "ASTAR",
    method: str = "histogram",
    noise_std: float = 0.6,
    motion_success: float = 0.85,
    num_particles: int = 300,
    seed: Optional[int] = None,
) -> dict:
    """Plan a path, then drive + localize along it, returning frames + summary."""
    rng = np.random.default_rng(seed)

    # ---- 1. Plan the route (CO2 / CO3) ------------------------------ #
    plan = plan_path(grid, algorithm, seed=seed)
    if not plan.success:
        return {"success": False, "plan": plan.to_dict(), "frames": [],
                "summary": {}, "trace": [], "message": plan.note}

    # ---- 2. Set up the world + chosen filter (CO5) ------------------ #
    robot = Robot(grid, *grid.start)
    sensor = RangeSensor(grid, noise_std=noise_std, rng=rng)
    loc = make_filter(method, grid, sensor, motion_success, num_particles, rng)
    is_particle = method.lower() == "particle"

    frames: List[dict] = []
    errors: List[int] = []
    trace: List[dict] = [{"step": 0, "text": f"Planned a path with {plan.algorithm}; "
                                             f"localizing with the {method} filter."}]

    def make_frame(step: int, action: Optional[str]) -> dict:
        true_pos = robot.position
        reading = sensor.noisy_reading(true_pos)
        loc.update(reading)                       # sensor correction (Bayes update)
        est = loc.estimated_position()
        err = manhattan(true_pos, est)
        errors.append(err)
        frame = {
            "step": step, "action": action,
            "true_pos": list(true_pos), "est_pos": list(est),
            "x": true_pos[0], "y": true_pos[1],
            "sensors": {k: round(v, 2) for k, v in reading.items()},
            "error": err,
            "confidence": round(loc.confidence(), 4),
            "entropy": round(loc.entropy(), 4),
            "top_cells": [[list(c), p] for c, p in loc.top_cells(5)],
            "belief": loc.belief_grid(),
        }
        if is_particle:
            frame["particles"] = loc.particle_points(200)
        return frame

    # ---- 3. First frame: robot sits at the start -------------------- #
    frames.append(make_frame(step=0, action=None))

    # ---- 4. Drive along the planned path ---------------------------- #
    for step, nxt in enumerate(plan.path[1:], start=1):
        action = _action_between(robot.position, nxt)
        if action is None:
            robot.move_to(nxt)                    # non-adjacent hop (CSP path)
        else:
            loc.predict(action)                   # motion prediction
            robot.move(action)
        frames.append(make_frame(step=step, action=action))
        if step <= 3:
            trace.append({"step": step,
                          "text": f"Moved {action}; sensors updated the belief; "
                                  f"error now {errors[-1]} cell(s)."})

    # ---- 5. Summarise ---------------------------------------------- #
    avg_err = float(np.mean(errors)) if errors else 0.0
    summary = {
        "algorithm": plan.algorithm,
        "method": method,
        "path_length": len(plan.path),
        "path_cost": plan.cost,
        "nodes_expanded": plan.nodes_expanded,
        "plan_time_ms": round(plan.time_ms, 3),
        "steps_simulated": len(frames),
        "avg_localization_error": round(avg_err, 3),
        "final_localization_error": errors[-1] if errors else 0,
        "final_confidence": frames[-1]["confidence"] if frames else 0.0,
    }
    trace.append({"step": len(frames) - 1,
                  "text": f"Finished: average error {summary['avg_localization_error']} "
                          f"cells, final confidence {int(summary['final_confidence']*100)}%."})

    return {"success": True, "plan": plan.to_dict(), "frames": frames,
            "summary": summary, "trace": trace, "message": plan.note}


def compare_planners(grid: GridMap, seed: Optional[int] = None) -> List[dict]:
    """Run every planner on the same map -- the CO2/CO3 time/space comparison."""
    names = list(PLANNERS.keys()) + ["CSP_MINCONFLICTS"]
    return [plan_path(grid, name, seed=seed).to_dict() for name in names]
