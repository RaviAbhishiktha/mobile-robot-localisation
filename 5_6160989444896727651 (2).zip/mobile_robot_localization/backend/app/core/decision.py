"""
decision.py
===========
Decision-making under uncertainty (CO4): **active localization**.

Most of this project plans a route and *then* localizes. Here we flip it: the
robot does not know where it is, and it must **choose moves that make it figure
out its location fastest**. That is a utility-based policy -- at each step it
scores every possible move and picks the one with the highest *information*
utility -- and it ties CO4 (decision making) to CO5 (the belief filter) and CO6
(an explainable trace of why each move was chosen).

THE UTILITY (why a move is "good")
----------------------------------
A move is informative if, after taking it, the robot's likely positions would
give *different* sensor readings -- because the next reading will then split
those positions apart. So for each action we look at the current top belief
cells, move them, and measure how much their expected sensor readings disagree.
More disagreement = more disambiguating = higher utility.
"""

from __future__ import annotations

from typing import List, Optional, Tuple

import numpy as np

from .grid import GridMap, MOVES_4
from .robot import Robot
from .sensors import RangeSensor, SENSOR_DIRECTIONS
from .simulation import make_filter


def _reading_vector(sensor: RangeSensor, cell) -> np.ndarray:
    r = sensor.true_reading(cell)
    return np.array([r[d] for d in SENSOR_DIRECTIONS], dtype=float)


def action_utility(grid: GridMap, sensor: RangeSensor,
                   hypotheses: List[Tuple[Tuple[int, int], float]], action: str) -> float:
    """
    Score one action by how much it would separate the current hypotheses.

    `hypotheses` is a list of (cell, probability). We move each hypothesis by
    the action, get its expected reading, and measure the spread (belief-weighted
    variance) of those readings. Higher spread = more informative move.
    """
    dx, dy = MOVES_4[action]
    vectors, weights = [], []
    for (x, y), p in hypotheses:
        target = (x + dx, y + dy)
        cell = target if grid.is_free(target) else (x, y)   # blocked -> stays
        vectors.append(_reading_vector(sensor, cell))
        weights.append(p)
    if not vectors:
        return 0.0
    arr = np.array(vectors)
    w = np.array(weights)
    w = w / (w.sum() + 1e-12)
    mean = np.average(arr, axis=0, weights=w)
    variance = np.average((arr - mean) ** 2, axis=0, weights=w)
    return float(variance.sum())


def choose_localizing_action(grid: GridMap, sensor: RangeSensor, loc) -> Tuple[str, dict]:
    """Pick the most informative legal action and explain the choice."""
    hypotheses = loc.top_cells(6)
    best_action, best_score = None, -1.0
    scored = {}
    for action in MOVES_4:
        score = action_utility(grid, sensor, hypotheses, action)
        scored[action] = round(score, 3)
        if score > best_score:
            best_action, best_score = action, score
    reason = (f"Chose {best_action}: it best separates the robot's likely "
              f"positions (utility {best_score:.2f}).")
    return best_action, {"scores": scored, "reason": reason}


def run_active_localization(
    grid: GridMap,
    method: str = "histogram",
    true_start: Optional[Tuple[int, int]] = None,
    noise_std: float = 0.6,
    motion_success: float = 0.85,
    num_particles: int = 300,
    max_steps: int = 25,
    seed: Optional[int] = None,
) -> dict:
    """
    Run the active-localization loop: starting from a *uniform* belief, repeatedly
    pick the most informative move until the robot is confident where it is.
    Returns animation frames plus a decision trace (CO6).
    """
    rng = np.random.default_rng(seed)
    sensor = RangeSensor(grid, noise_std=noise_std, rng=rng)
    loc = make_filter(method, grid, sensor, motion_success, num_particles, rng)
    is_particle = method.lower() == "particle"

    # The robot's real (hidden) starting cell -- the filter does NOT know this.
    start = true_start or grid.free_cells()[len(grid.free_cells()) // 2]
    robot = Robot(grid, *start)

    frames: List[dict] = []
    trace: List[dict] = [{"step": 0, "text": "Belief starts uniform: the robot "
                                             "has no idea where it is yet."}]

    def snapshot(step: int, action: Optional[str], reason: str = "") -> dict:
        reading = sensor.noisy_reading(robot.position)
        loc.update(reading)
        est = loc.estimated_position()
        err = abs(est[0] - robot.x) + abs(est[1] - robot.y)
        frame = {
            "step": step, "action": action,
            "true_pos": [robot.x, robot.y], "est_pos": list(est),
            "x": robot.x, "y": robot.y,
            "sensors": {k: round(v, 2) for k, v in reading.items()},
            "error": err, "confidence": round(loc.confidence(), 4),
            "entropy": round(loc.entropy(), 4),
            "top_cells": [[list(c), p] for c, p in loc.top_cells(5)],
            "belief": loc.belief_grid(), "reason": reason,
        }
        if is_particle:
            frame["particles"] = loc.particle_points(200)
        return frame

    frames.append(snapshot(0, None, "Initial sensor reading taken."))

    for step in range(1, max_steps + 1):
        action, info = choose_localizing_action(grid, sensor, loc)
        loc.predict(action)
        robot.move(action)
        frames.append(snapshot(step, action, info["reason"]))
        if step <= 6:
            trace.append({"step": step, "text": info["reason"]})
        # Stop once the belief is confident (entropy low / one cell dominant).
        if frames[-1]["confidence"] > 0.6 or frames[-1]["entropy"] < 0.4:
            trace.append({"step": step, "text": "Confident now -- localization "
                                                "achieved, stopping early."})
            break

    final = frames[-1]
    summary = {
        "method": method, "steps": len(frames),
        "final_error": final["error"], "final_confidence": final["confidence"],
        "final_entropy": final["entropy"],
        "localized": bool(final["confidence"] > 0.6 or final["entropy"] < 0.4),
    }
    return {"success": True, "frames": frames, "trace": trace, "summary": summary,
            "message": "Active localization run complete."}
