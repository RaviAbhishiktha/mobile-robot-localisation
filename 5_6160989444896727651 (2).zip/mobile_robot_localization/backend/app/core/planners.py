"""
planners.py
===========
Path-planning algorithms from CO2 ("Solving Problems by Searching").

Every planner answers the same question:
    "Starting at `start`, what sequence of cells leads to `goal`,
     stepping only UP/DOWN/LEFT/RIGHT through free cells?"

We implement the five algorithms the syllabus teaches and return a uniform
`SearchResult` so we can compare them fairly:

    BFS    - Breadth-First Search   (uses a FIFO queue)   -> shortest #steps
    DFS    - Depth-First Search     (uses a LIFO stack)   -> any path, fast/deep
    UCS    - Uniform-Cost Search    (priority queue on g) -> cheapest cost
    GREEDY - Greedy Best-First      (priority queue on h) -> fast, not optimal
    ASTAR  - A* Search              (priority queue on f=g+h) -> optimal + fast

`g(n)` is the cost so far; `h(n)` is the heuristic estimate to the goal
(here the Manhattan distance, which is admissible on a 4-connected grid).
"""

from __future__ import annotations

import heapq
import time
from collections import deque
from dataclasses import dataclass, field
from typing import Dict, List, Optional

from .grid import Cell, GridMap


@dataclass
class SearchResult:
    """Everything we want to know about one planning run."""
    algorithm: str
    success: bool
    path: List[Cell] = field(default_factory=list)  # start .. goal inclusive
    cost: int = 0                # number of steps (each step costs 1)
    nodes_expanded: int = 0      # how many cells we pulled from the frontier
    max_frontier: int = 0        # peak size of the frontier (memory proxy)
    time_ms: float = 0.0         # wall-clock time taken
    note: str = ""               # human-readable explanation (esp. on failure)

    def to_dict(self) -> dict:
        return {
            "algorithm": self.algorithm,
            "success": self.success,
            "path": [list(c) for c in self.path],
            "cost": self.cost,
            "nodes_expanded": self.nodes_expanded,
            "max_frontier": self.max_frontier,
            "time_ms": round(self.time_ms, 3),
            "note": self.note,
        }


def manhattan(a: Cell, b: Cell) -> int:
    """|dx| + |dy| -- the cost to walk between two cells if there were no walls."""
    return abs(a[0] - b[0]) + abs(a[1] - b[1])


def _reconstruct(came_from: Dict[Cell, Optional[Cell]], goal: Cell) -> List[Cell]:
    """Walk the 'parent' links backwards from goal to start, then reverse."""
    path: List[Cell] = []
    node: Optional[Cell] = goal
    while node is not None:
        path.append(node)
        node = came_from[node]
    path.reverse()
    return path


# --------------------------------------------------------------------- #
# Uninformed search (CO2, Session 5)
# --------------------------------------------------------------------- #
def bfs(grid: GridMap) -> SearchResult:
    """Breadth-First Search: explore the closest cells first using a queue."""
    t0 = time.perf_counter()
    start, goal = grid.start, grid.goal
    frontier: deque[Cell] = deque([start])      # FIFO queue
    came_from: Dict[Cell, Optional[Cell]] = {start: None}
    expanded = 0
    max_frontier = 1

    while frontier:
        current = frontier.popleft()            # take the OLDEST item
        expanded += 1
        if current == goal:
            path = _reconstruct(came_from, goal)
            return SearchResult("BFS", True, path, len(path) - 1, expanded,
                                max_frontier, (time.perf_counter() - t0) * 1000,
                                "Shortest path by number of steps.")
        for nxt in grid.neighbors(current):
            if nxt not in came_from:            # not seen yet
                came_from[nxt] = current
                frontier.append(nxt)
        max_frontier = max(max_frontier, len(frontier))

    return SearchResult("BFS", False, note="No path exists between start and goal.",
                        nodes_expanded=expanded, max_frontier=max_frontier,
                        time_ms=(time.perf_counter() - t0) * 1000)


def dfs(grid: GridMap) -> SearchResult:
    """Depth-First Search: dive deep first using a stack (LIFO)."""
    t0 = time.perf_counter()
    start, goal = grid.start, grid.goal
    frontier: List[Cell] = [start]              # LIFO stack
    came_from: Dict[Cell, Optional[Cell]] = {start: None}
    expanded = 0
    max_frontier = 1

    while frontier:
        current = frontier.pop()                # take the NEWEST item
        expanded += 1
        if current == goal:
            path = _reconstruct(came_from, goal)
            return SearchResult("DFS", True, path, len(path) - 1, expanded,
                                max_frontier, (time.perf_counter() - t0) * 1000,
                                "A valid path (not guaranteed to be shortest).")
        for nxt in grid.neighbors(current):
            if nxt not in came_from:
                came_from[nxt] = current
                frontier.append(nxt)
        max_frontier = max(max_frontier, len(frontier))

    return SearchResult("DFS", False, note="No path exists between start and goal.",
                        nodes_expanded=expanded, max_frontier=max_frontier,
                        time_ms=(time.perf_counter() - t0) * 1000)


def ucs(grid: GridMap) -> SearchResult:
    """Uniform-Cost Search: always expand the cheapest-so-far cell (priority queue)."""
    t0 = time.perf_counter()
    start, goal = grid.start, grid.goal
    # Heap items are (g_cost, tie_breaker, cell). The tie_breaker keeps the
    # heap stable and avoids comparing tuples of cells.
    counter = 0
    frontier: List[tuple] = [(0, counter, start)]
    came_from: Dict[Cell, Optional[Cell]] = {start: None}
    cost_so_far: Dict[Cell, int] = {start: 0}
    expanded = 0
    max_frontier = 1

    while frontier:
        g, _, current = heapq.heappop(frontier)
        expanded += 1
        if current == goal:
            path = _reconstruct(came_from, goal)
            return SearchResult("UCS", True, path, cost_so_far[goal], expanded,
                                max_frontier, (time.perf_counter() - t0) * 1000,
                                "Cheapest-cost path (here equals fewest steps).")
        for nxt in grid.neighbors(current):
            new_cost = g + 1                    # every step costs 1
            if nxt not in cost_so_far or new_cost < cost_so_far[nxt]:
                cost_so_far[nxt] = new_cost
                came_from[nxt] = current
                counter += 1
                heapq.heappush(frontier, (new_cost, counter, nxt))
        max_frontier = max(max_frontier, len(frontier))

    return SearchResult("UCS", False, note="No path exists between start and goal.",
                        nodes_expanded=expanded, max_frontier=max_frontier,
                        time_ms=(time.perf_counter() - t0) * 1000)


# --------------------------------------------------------------------- #
# Informed search (CO2, Session 6 & 7)
# --------------------------------------------------------------------- #
def greedy(grid: GridMap) -> SearchResult:
    """Greedy Best-First: expand whatever *looks* closest to the goal (h only)."""
    t0 = time.perf_counter()
    start, goal = grid.start, grid.goal
    counter = 0
    frontier: List[tuple] = [(manhattan(start, goal), counter, start)]
    came_from: Dict[Cell, Optional[Cell]] = {start: None}
    expanded = 0
    max_frontier = 1

    while frontier:
        _, _, current = heapq.heappop(frontier)
        expanded += 1
        if current == goal:
            path = _reconstruct(came_from, goal)
            return SearchResult("GREEDY", True, path, len(path) - 1, expanded,
                                max_frontier, (time.perf_counter() - t0) * 1000,
                                "Fast, but the path may not be the shortest.")
        for nxt in grid.neighbors(current):
            if nxt not in came_from:
                came_from[nxt] = current
                counter += 1
                heapq.heappush(frontier, (manhattan(nxt, goal), counter, nxt))
        max_frontier = max(max_frontier, len(frontier))

    return SearchResult("GREEDY", False, note="No path exists between start and goal.",
                        nodes_expanded=expanded, max_frontier=max_frontier,
                        time_ms=(time.perf_counter() - t0) * 1000)


def astar(grid: GridMap) -> SearchResult:
    """A* Search: balance cost-so-far g(n) and estimate h(n) via f = g + h."""
    t0 = time.perf_counter()
    start, goal = grid.start, grid.goal
    counter = 0
    frontier: List[tuple] = [(manhattan(start, goal), counter, start)]
    came_from: Dict[Cell, Optional[Cell]] = {start: None}
    cost_so_far: Dict[Cell, int] = {start: 0}
    expanded = 0
    max_frontier = 1

    while frontier:
        _, _, current = heapq.heappop(frontier)
        expanded += 1
        if current == goal:
            path = _reconstruct(came_from, goal)
            return SearchResult("ASTAR", True, path, cost_so_far[goal], expanded,
                                max_frontier, (time.perf_counter() - t0) * 1000,
                                "Optimal path, explored efficiently using the heuristic.")
        for nxt in grid.neighbors(current):
            new_cost = cost_so_far[current] + 1
            if nxt not in cost_so_far or new_cost < cost_so_far[nxt]:
                cost_so_far[nxt] = new_cost
                priority = new_cost + manhattan(nxt, goal)  # f = g + h
                came_from[nxt] = current
                counter += 1
                heapq.heappush(frontier, (priority, counter, nxt))
        max_frontier = max(max_frontier, len(frontier))

    return SearchResult("ASTAR", False, note="No path exists between start and goal.",
                        nodes_expanded=expanded, max_frontier=max_frontier,
                        time_ms=(time.perf_counter() - t0) * 1000)


# A registry so the API can pick a planner by name.
PLANNERS = {
    "BFS": bfs,
    "DFS": dfs,
    "UCS": ucs,
    "GREEDY": greedy,
    "ASTAR": astar,
}
