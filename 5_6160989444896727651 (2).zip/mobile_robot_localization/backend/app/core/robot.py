"""
robot.py
========
The robot's *true* state and how it moves.

In a real robot this state would be unknown to us (we'd only have noisy
sensors). Here we keep the true position so we can:
  1. simulate what the sensors *would* read, and
  2. measure how good our localization estimate is (true vs estimated).
"""

from __future__ import annotations

from dataclasses import dataclass

from .grid import Cell, GridMap, MOVES_4


@dataclass
class Robot:
    """
    Holds the robot's true (x, y) position on the grid.

    `grid_map` is kept so the robot can refuse to walk into walls.
    """

    grid_map: GridMap
    x: int
    y: int

    @property
    def position(self) -> Cell:
        """Return the current position as an (x, y) tuple."""
        return (self.x, self.y)

    def can_move(self, action: str) -> bool:
        """Check whether `action` (e.g. 'UP') leads to a free cell."""
        dx, dy = MOVES_4[action]
        target = (self.x + dx, self.y + dy)
        return self.grid_map.is_free(target)

    def move(self, action: str) -> bool:
        """
        Try to move in the given direction.

        Returns True if the robot actually moved, or False if the move was
        blocked by a wall / edge (in which case the robot stays put).
        """
        if not self.can_move(action):
            return False
        dx, dy = MOVES_4[action]
        self.x += dx
        self.y += dy
        return True

    def move_to(self, cell: Cell) -> None:
        """Teleport directly to a cell (used when following a planned path)."""
        if not self.grid_map.is_free(cell):
            raise ValueError(f"cannot place robot on blocked cell {cell}")
        self.x, self.y = cell
