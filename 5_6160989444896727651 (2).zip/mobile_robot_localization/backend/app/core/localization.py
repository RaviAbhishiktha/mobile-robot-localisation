"""
localization.py
===============
Grid-based ("histogram") localization, also known as a discrete Bayes filter.

THE IDEA (in plain words)
-------------------------
The robot does NOT know exactly where it is. Instead it keeps a *belief*:
a probability for every free cell, answering "how likely am I to be here?".

The belief is updated in two repeating steps as the robot moves:

  1. PREDICT (motion update)
     "I just tried to move RIGHT, so my belief should shift right too."
     We move the probability mass in the direction of the action, and we
     smear it slightly to account for the fact that motion is imperfect.

  2. UPDATE (sensor / measurement update)
     "My sensors read these distances. Which cells would produce readings
     like that?" Cells whose *expected* readings match the *observed*
     readings get their probability boosted; others get reduced. Then we
     re-normalise so all probabilities add up to 1.

Over several steps the belief concentrates on the robot's true location.
This is exactly the kind of state-tracking the course builds on top of its
grid / state-class / probability data-structure foundations.
"""

from __future__ import annotations

from typing import Dict, List, Tuple

import numpy as np

from .grid import Cell, GridMap, MOVES_4
from .sensors import RangeSensor, SENSOR_DIRECTIONS

# A tiny number we add so probabilities are never exactly zero.
# This keeps the maths stable (we never divide by zero when normalising).
EPS: float = 1e-12


class GridLocalization:
    """
    Discrete Bayes filter over the free cells of a GridMap.

    The belief is stored as a 2D NumPy array `self.belief` shaped
    (height, width); obstacle cells are forced to probability 0.
    """

    def __init__(
        self,
        grid_map: GridMap,
        sensor: RangeSensor,
        motion_success: float = 0.85,
    ) -> None:
        self.grid_map = grid_map
        self.sensor = sensor
        # Probability that an intended move actually happens. The remaining
        # mass is spread to neighbouring outcomes to model motion noise.
        self.motion_success = float(motion_success)

        # A boolean mask of which cells are free (True) vs blocked (False).
        self.free_mask = np.array(
            [[grid_map.grid[y][x] == 0 for x in range(grid_map.width)]
             for y in range(grid_map.height)],
            dtype=bool,
        )

        # Pre-compute the *expected* sensor reading for every cell once.
        # (The map does not change during a run, so this never changes.)
        self._expected = self._precompute_expected_readings()

        # Start with a uniform belief over all free cells.
        self.belief = self._uniform_belief()

    # --------------------------------------------------------------- #
    # Setup helpers
    # --------------------------------------------------------------- #
    def _uniform_belief(self) -> np.ndarray:
        """Equal probability on every free cell, zero on obstacles."""
        belief = self.free_mask.astype(float)
        return belief / belief.sum()

    def _precompute_expected_readings(self) -> Dict[Cell, Dict[str, int]]:
        """For each free cell, store the noise-free sensor reading it implies."""
        table: Dict[Cell, Dict[str, int]] = {}
        for cell in self.grid_map.free_cells():
            table[cell] = self.sensor.true_reading(cell)
        return table

    # --------------------------------------------------------------- #
    # Step 1: PREDICT (motion update)
    # --------------------------------------------------------------- #
    def predict(self, action: str) -> None:
        """
        Shift the belief in the direction of `action`.

        Most of the probability (motion_success) moves to the intended cell.
        If the intended cell is blocked or off-grid, that probability stays
        where it is (the robot bumped a wall). The leftover probability is
        kept in place to represent "the move might not have worked".
        """
        dx, dy = MOVES_4[action]
        new_belief = np.zeros_like(self.belief)
        stay_prob = 1.0 - self.motion_success

        for y in range(self.grid_map.height):
            for x in range(self.grid_map.width):
                p = self.belief[y, x]
                if p <= 0:
                    continue
                target = (x + dx, y + dy)
                if self.grid_map.is_free(target):
                    # Intended move succeeds with motion_success probability.
                    new_belief[target[1], target[0]] += p * self.motion_success
                    new_belief[y, x] += p * stay_prob
                else:
                    # Move blocked -> all the mass stays in the current cell.
                    new_belief[y, x] += p

        total = new_belief.sum()
        self.belief = new_belief / (total + EPS)

    # --------------------------------------------------------------- #
    # Step 2: UPDATE (sensor / measurement update)
    # --------------------------------------------------------------- #
    def update(self, observation: Dict[str, float]) -> None:
        """
        Re-weight the belief using a real (noisy) sensor reading.

        For each free cell we compute how *likely* the observed reading is,
        assuming the robot were standing there. We model each direction's
        error as a Gaussian, so a cell whose expected reading is close to
        what we observed gets a high likelihood.
        """
        sigma = max(self.sensor.noise_std, 0.25)  # avoid an absurdly sharp model
        likelihood = np.zeros_like(self.belief)

        for cell, expected in self._expected.items():
            x, y = cell
            # Product of per-direction Gaussian likelihoods.
            log_like = 0.0
            for name in SENSOR_DIRECTIONS:
                diff = observation[name] - expected[name]
                log_like += -0.5 * (diff / sigma) ** 2
            likelihood[y, x] = np.exp(log_like)

        # Bayes rule: new_belief ∝ likelihood * prior_belief
        posterior = likelihood * self.belief
        total = posterior.sum()
        if total <= EPS:
            # Reading matched nothing well (very noisy). Keep the old belief
            # rather than collapsing to zeros everywhere.
            return
        self.belief = posterior / total

    # --------------------------------------------------------------- #
    # Reading the belief
    # --------------------------------------------------------------- #
    def estimated_position(self) -> Cell:
        """The single most-likely cell (the 'argmax' of the belief)."""
        y, x = np.unravel_index(int(np.argmax(self.belief)), self.belief.shape)
        return (int(x), int(y))

    def confidence(self) -> float:
        """Probability mass sitting on the most-likely cell (0..1)."""
        return float(self.belief.max())

    def top_cells(self, k: int = 5) -> List[Tuple[Cell, float]]:
        """The k most-likely cells and their probabilities (for the UI)."""
        flat = self.belief.flatten()
        idx = np.argsort(flat)[::-1][:k]
        out: List[Tuple[Cell, float]] = []
        for i in idx:
            y, x = np.unravel_index(int(i), self.belief.shape)
            out.append(((int(x), int(y)), round(float(flat[i]), 5)))
        return out

    def entropy(self) -> float:
        """
        Shannon entropy of the belief: high when the robot is unsure (mass
        spread over many cells), low when it is confident (mass on one cell).
        Used by the active-localization decision policy (CO4).
        """
        b = self.belief[self.belief > 0]
        return float(-np.sum(b * np.log(b + EPS)))

    def belief_grid(self) -> List[List[float]]:
        """The whole belief as a plain list-of-lists (for the heatmap)."""
        return [[round(float(v), 6) for v in row] for row in self.belief]
