"""
database.py
===========
A tiny wrapper around Python's built-in SQLite database.

SQLite needs no server -- the whole database is a single file on disk
(robot.db). We use it to remember saved maps and the results of past
simulation runs so they can be listed in the UI.
"""

from __future__ import annotations

import sqlite3
from pathlib import Path

# The database file lives next to the backend package.
DB_PATH = Path(__file__).resolve().parent.parent / "robot.db"

# SQL that creates our two tables if they do not already exist.
SCHEMA = """
CREATE TABLE IF NOT EXISTS maps (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    name       TEXT NOT NULL,
    width      INTEGER NOT NULL,
    height     INTEGER NOT NULL,
    grid_json  TEXT NOT NULL,      -- the 2D grid, stored as JSON text
    start_json TEXT NOT NULL,      -- [x, y]
    goal_json  TEXT NOT NULL,      -- [x, y]
    created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS runs (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    algorithm       TEXT NOT NULL,
    path_cost       INTEGER,
    nodes_expanded  INTEGER,
    plan_time_ms    REAL,
    steps           INTEGER,
    avg_error       REAL,
    final_error     INTEGER,
    summary_json    TEXT NOT NULL,  -- the full summary dict as JSON
    created_at      TEXT DEFAULT CURRENT_TIMESTAMP
);
"""


def get_connection() -> sqlite3.Connection:
    """
    Open a connection to the SQLite file.

    `row_factory = sqlite3.Row` lets us read columns by name (row["id"])
    instead of by numeric index, which is much easier to read.
    """
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db() -> None:
    """Create the tables on first run. Safe to call every time the app starts."""
    with get_connection() as conn:
        conn.executescript(SCHEMA)
