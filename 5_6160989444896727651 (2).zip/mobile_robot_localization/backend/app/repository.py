"""
repository.py
=============
All the SQL read/write helpers in one place, so the rest of the app never
has to write raw SQL. This is the "data access layer".
"""

from __future__ import annotations

import json
from typing import List, Optional

from .database import get_connection


# --------------------------- maps --------------------------------- #
def save_map(name: str, width: int, height: int, grid, start, goal) -> int:
    """Insert a map and return its new id."""
    with get_connection() as conn:
        cur = conn.execute(
            "INSERT INTO maps (name, width, height, grid_json, start_json, goal_json) "
            "VALUES (?, ?, ?, ?, ?, ?)",
            (name, width, height, json.dumps(grid), json.dumps(start), json.dumps(goal)),
        )
        return int(cur.lastrowid)


def list_maps() -> List[dict]:
    """Return all saved maps (newest first)."""
    with get_connection() as conn:
        rows = conn.execute(
            "SELECT id, name, width, height, created_at FROM maps ORDER BY id DESC"
        ).fetchall()
        return [dict(r) for r in rows]


def get_map(map_id: int) -> Optional[dict]:
    """Return one full map (grid included) or None if it doesn't exist."""
    with get_connection() as conn:
        row = conn.execute("SELECT * FROM maps WHERE id = ?", (map_id,)).fetchone()
        if row is None:
            return None
        return {
            "id": row["id"],
            "name": row["name"],
            "width": row["width"],
            "height": row["height"],
            "grid": json.loads(row["grid_json"]),
            "start": json.loads(row["start_json"]),
            "goal": json.loads(row["goal_json"]),
            "created_at": row["created_at"],
        }


# --------------------------- runs --------------------------------- #
def save_run(summary: dict) -> int:
    """Store a simulation summary and return its new id."""
    with get_connection() as conn:
        cur = conn.execute(
            "INSERT INTO runs (algorithm, path_cost, nodes_expanded, plan_time_ms, "
            "steps, avg_error, final_error, summary_json) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            (
                summary.get("algorithm"),
                summary.get("path_cost"),
                summary.get("nodes_expanded"),
                summary.get("plan_time_ms"),
                summary.get("steps_simulated"),
                summary.get("avg_localization_error"),
                summary.get("final_localization_error"),
                json.dumps(summary),
            ),
        )
        return int(cur.lastrowid)


def list_runs(limit: int = 50) -> List[dict]:
    """Return recent runs (newest first)."""
    with get_connection() as conn:
        rows = conn.execute(
            "SELECT id, algorithm, path_cost, nodes_expanded, plan_time_ms, steps, "
            "avg_error, final_error, created_at FROM runs ORDER BY id DESC LIMIT ?",
            (limit,),
        ).fetchall()
        return [dict(r) for r in rows]


def get_run(run_id: int) -> Optional[dict]:
    """Return one run's full summary or None."""
    with get_connection() as conn:
        row = conn.execute("SELECT * FROM runs WHERE id = ?", (run_id,)).fetchone()
        if row is None:
            return None
        data = dict(row)
        data["summary"] = json.loads(row["summary_json"])
        return data
