"""
start.py — launches the Python backend AND opens the app in your browser
automatically. Just run this (or double-click run.bat); you don't have to
click any link or type any address.

    py -3.13 start.py
"""
import threading
import time
import webbrowser

import uvicorn
from app.main import app

URL = "http://127.0.0.1:8000"


def _open_browser() -> None:
    # Wait a moment for the server to be ready, then open the page itself.
    time.sleep(1.8)
    webbrowser.open(URL)


if __name__ == "__main__":
    print("Starting Mobile Robot Localization...")
    print("Your browser will open the app automatically in a second.")
    print("Keep THIS window open while you use the app.")
    print("(Close this window, or press Ctrl+C, to stop.)\n")
    threading.Thread(target=_open_browser, daemon=True).start()
    # reload=False -> one stable process (no helper process that can die on Windows)
    uvicorn.run(app, host="127.0.0.1", port=8000, log_level="info")
