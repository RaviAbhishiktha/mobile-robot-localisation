"""Unit tests for the path planners (CO2) and the CSP planner (CO3)."""
from app.core.grid import GridMap
from app.core.planners import bfs, dfs, ucs, greedy, astar, manhattan
from app.core.csp_planner import csp_min_conflicts


def open_grid():
    """A 5x5 grid with no obstacles."""
    grid = [[0] * 5 for _ in range(5)]
    return GridMap(width=5, height=5, grid=grid, start=(0, 0), goal=(4, 4))


def walled_grid():
    """A grid where the goal is completely walled off -> no path."""
    grid = [
        [0, 0, 1, 0],
        [0, 0, 1, 0],
        [1, 1, 1, 0],
        [0, 0, 0, 0],
    ]
    # Wall the goal (3,0) off behind column-2 wall + isolate it.
    grid = [
        [0, 0, 1, 9],
        [0, 0, 1, 9],
        [0, 0, 1, 9],
        [0, 0, 1, 9],
    ]
    # replace 9 with obstacle surround so (3,*) is unreachable
    g = [[1 if v == 9 else v for v in row] for row in grid]
    return GridMap(width=4, height=4, grid=g, start=(0, 0), goal=(3, 0))


def test_all_planners_find_a_path_on_open_grid():
    g = open_grid()
    for planner in (bfs, dfs, ucs, greedy, astar):
        res = planner(g)
        assert res.success, planner.__name__
        assert res.path[0] == (0, 0)
        assert res.path[-1] == (4, 4)


def test_optimal_planners_find_shortest_path():
    g = open_grid()
    # On an open 5x5 grid the shortest path has 8 steps (Manhattan distance).
    assert bfs(g).cost == 8
    assert ucs(g).cost == 8
    assert astar(g).cost == 8


def test_path_is_connected():
    g = open_grid()
    path = astar(g).path
    for a, b in zip(path, path[1:]):
        assert manhattan(a, b) == 1   # every step is to an adjacent cell


def test_no_path_reports_failure():
    g = walled_grid()
    assert not bfs(g).success
    assert not astar(g).success


def test_csp_min_conflicts_solves_open_grid():
    g = open_grid()
    res = csp_min_conflicts(g, seed=42)
    assert res.success
    assert res.path[0] == (0, 0)
    assert res.path[-1] == (4, 4)
    for a, b in zip(res.path, res.path[1:]):
        assert manhattan(a, b) == 1
