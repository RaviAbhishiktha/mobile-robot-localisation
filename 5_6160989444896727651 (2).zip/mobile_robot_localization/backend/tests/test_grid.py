"""Unit tests for the GridMap world model."""
import pytest

from app.core.grid import GridMap, FREE, OBSTACLE


def make_grid():
    grid = [
        [0, 0, 0],
        [0, 1, 0],
        [0, 0, 0],
    ]
    return GridMap(width=3, height=3, grid=grid, start=(0, 0), goal=(2, 2))


def test_in_bounds():
    g = make_grid()
    assert g.in_bounds((0, 0))
    assert g.in_bounds((2, 2))
    assert not g.in_bounds((3, 0))
    assert not g.in_bounds((-1, 0))


def test_is_free():
    g = make_grid()
    assert g.is_free((0, 0))
    assert not g.is_free((1, 1))      # the obstacle
    assert not g.is_free((5, 5))      # out of bounds


def test_neighbors_excludes_walls_and_edges():
    g = make_grid()
    # Corner (0,0): only RIGHT (1,0) and DOWN (0,1) are valid & free.
    assert set(g.neighbors((0, 0))) == {(1, 0), (0, 1)}
    # (1,0) sits above the obstacle, so DOWN (1,1) is excluded.
    assert (1, 1) not in g.neighbors((1, 0))


def test_free_cells_count():
    g = make_grid()
    assert len(g.free_cells()) == 8   # 9 cells minus 1 obstacle


def test_invalid_grid_raises():
    with pytest.raises(ValueError):
        GridMap(width=3, height=2, grid=[[0, 0, 0]], start=(0, 0), goal=(2, 0))
