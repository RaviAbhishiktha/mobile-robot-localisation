"""Unit tests for sensors and grid-based localization."""
import numpy as np

from app.core.grid import GridMap
from app.core.sensors import RangeSensor
from app.core.localization import GridLocalization
from app.core.simulation import run_simulation


def open_grid():
    grid = [[0] * 6 for _ in range(6)]
    return GridMap(width=6, height=6, grid=grid, start=(0, 0), goal=(5, 5))


def test_true_reading_corner():
    g = open_grid()
    s = RangeSensor(g, noise_std=0.0)
    r = s.true_reading((0, 0))
    # At the top-left corner: nothing above or to the left (0),
    # 5 free cells to the right and 5 below.
    assert r["UP"] == 0
    assert r["LEFT"] == 0
    assert r["RIGHT"] == 5
    assert r["DOWN"] == 5


def test_noisy_reading_nonnegative():
    g = open_grid()
    s = RangeSensor(g, noise_std=1.0, rng=np.random.default_rng(0))
    for _ in range(50):
        r = s.noisy_reading((2, 2))
        assert all(v >= 0 for v in r.values())


def test_belief_sums_to_one():
    g = open_grid()
    s = RangeSensor(g, noise_std=0.5, rng=np.random.default_rng(1))
    loc = GridLocalization(g, s)
    assert abs(loc.belief.sum() - 1.0) < 1e-9
    loc.predict("RIGHT")
    assert abs(loc.belief.sum() - 1.0) < 1e-6
    loc.update(s.true_reading((1, 0)))
    assert abs(loc.belief.sum() - 1.0) < 1e-6


def test_localization_error_is_small_with_clean_sensors():
    g = open_grid()
    # With low noise the estimate should track the true position well.
    result = run_simulation(g, algorithm="ASTAR", noise_std=0.2,
                            motion_success=0.95, seed=7)
    assert result["success"]
    assert result["summary"]["avg_localization_error"] < 3.0
