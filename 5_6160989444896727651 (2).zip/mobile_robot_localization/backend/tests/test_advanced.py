"""Unit tests for the full-syllabus additions: particle filter (CO5),
backtracking CSP (CO3), and active localization (CO4)."""
import numpy as np

from app.core.grid import GridMap
from app.core.sensors import RangeSensor
from app.core.particle_filter import ParticleFilter
from app.core.csp_backtracking import solve_zone_assignment, build_zone_csp, ac3
from app.core.decision import run_active_localization
from app.core.simulation import run_simulation


def open_grid(n=8):
    grid = [[0] * n for _ in range(n)]
    return GridMap(width=n, height=n, grid=grid, start=(0, 0), goal=(n - 1, n - 1))


# ---------------- particle filter (CO5) ---------------- #
def test_particle_filter_weights_normalised():
    g = open_grid()
    s = RangeSensor(g, noise_std=0.5, rng=np.random.default_rng(0))
    pf = ParticleFilter(g, s, num_particles=200, rng=np.random.default_rng(0))
    pf.predict("RIGHT")
    pf.update(s.true_reading((1, 0)))
    assert abs(pf.weights.sum() - 1.0) < 1e-6
    assert len(pf.particles) == 200


def test_particle_filter_localizes():
    g = open_grid()
    # Low noise -> the particle cloud should converge near the true path.
    result = run_simulation(g, algorithm="ASTAR", method="particle",
                            noise_std=0.2, motion_success=0.95, seed=5)
    assert result["success"]
    assert result["summary"]["final_localization_error"] <= 3
    assert "particles" in result["frames"][-1]


# ---------------- backtracking CSP (CO3) ---------------- #
def test_zone_csp_solvable_with_enough_channels():
    g = open_grid(12)
    r = solve_zone_assignment(g, block=4, channels=4)
    assert r["success"]
    # Check the returned assignment actually satisfies all constraints.
    csp, _ = build_zone_csp(g, block=4, channels=4)
    a = r["assignment"]
    for v in csp.variables:
        for n in csp.neighbors[v]:
            assert a[v] != a[n], f"{v} and {n} share a channel"


def test_zone_csp_fails_with_too_few_channels():
    g = open_grid(12)
    r = solve_zone_assignment(g, block=4, channels=2)
    assert not r["success"]      # king-adjacency makes 2 channels impossible


def test_ac3_runs():
    g = open_grid(12)
    csp, _ = build_zone_csp(g, block=4, channels=4)
    assert ac3(csp) is True


# ---------------- active localization (CO4) ---------------- #
def test_active_localization_reduces_uncertainty():
    g = open_grid(10)
    r = run_active_localization(g, method="histogram", max_steps=20, seed=1)
    assert r["success"]
    # Entropy at the end should be lower than at the very start.
    start_entropy = r["frames"][0]["entropy"]
    end_entropy = r["frames"][-1]["entropy"]
    assert end_entropy <= start_entropy
    assert len(r["trace"]) >= 1
