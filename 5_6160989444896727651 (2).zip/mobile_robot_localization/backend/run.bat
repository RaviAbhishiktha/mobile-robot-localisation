@echo off
cd /d "%~dp0"
title Mobile Robot Localization
py -3.13 --version >nul 2>nul
if %errorlevel%==0 (
    py -3.13 start.py
) else (
    python start.py
)
echo.
echo ============================================================
echo  The server has stopped. If there are errors above, copy them.
echo  Press any key to close this window.
echo ============================================================
pause >nul
